package cl.minutaai.app

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

class SettingsActivity : AppCompatActivity() {
    private lateinit var modelStatus: TextView
    private lateinit var speechStatus: TextView
    private lateinit var keepAudioCheck: CheckBox
    private lateinit var globalGlossaryInput: EditText
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val pickModel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) importModel(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_settings)
        modelStatus = findViewById(R.id.modelStatus); speechStatus = findViewById(R.id.speechStatus); keepAudioCheck = findViewById(R.id.keepAudioCheck); globalGlossaryInput = findViewById(R.id.globalGlossaryInput)
        keepAudioCheck.isChecked = OfflineModelSettings.keepAudio(this)
        globalGlossaryInput.setText(KnowledgeStore(this).globalGlossary())
        keepAudioCheck.setOnCheckedChangeListener { _, checked -> OfflineModelSettings.setKeepAudio(this, checked) }
        renderStatus()
        findViewById<Button>(R.id.saveGlossaryButton).setOnClickListener { KnowledgeStore(this).setGlobalGlossary(globalGlossaryInput.text.toString()); Toast.makeText(this, "Glosario guardado.", Toast.LENGTH_SHORT).show() }
        findViewById<Button>(R.id.importModelButton).setOnClickListener { pickModel.launch(arrayOf("application/octet-stream", "*/*")) }
        findViewById<Button>(R.id.removeModelButton).setOnClickListener {
            val path = OfflineModelSettings.llmModelPath(this); if (path.isNotBlank()) File(path).delete(); OfflineModelSettings.setLlmModelPath(this, ""); renderStatus(); Toast.makeText(this, "Modelo generativo local eliminado.", Toast.LENGTH_SHORT).show()
        }
    }
    private fun renderStatus() {
        speechStatus.text = "V0.6.1 Trabajo: Vosk transcribe en vivo y Whisper Small q5_1 vuelve a procesar el WAV con timestamps al finalizar. La minuta se genera solo después de que revises el texto."
        val path = OfflineModelSettings.llmModelPath(this)
        modelStatus.text = if (OfflineModelSettings.hasLlmModel(this)) "IA local instalada: ${File(path).name} (${formatBytes(File(path).length())})" else "Sin LLM opcional. La minuta usa análisis extractivo conservador sobre la transcripción Whisper."
    }
    private fun importModel(uri: Uri) {
        modelStatus.text = "Importando modelo…"
        ioExecutor.execute {
            try {
                val dir = File(filesDir, "models/llm").apply { mkdirs() }; val name = queryName(uri) ?: "model.task"; val target = File(dir, "minuta_model.${name.substringAfterLast('.', "task")}")
                contentResolver.openInputStream(uri).use { nullable -> val input = requireNotNull(nullable) { "No pude abrir el archivo" }; FileOutputStream(target).use { output -> input.copyTo(output, 1024 * 1024) } }
                OfflineModelSettings.setLlmModelPath(this, target.absolutePath)
                runOnUiThread { renderStatus(); Toast.makeText(this, "Modelo importado.", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) { runOnUiThread { renderStatus(); Toast.makeText(this, "No pude importar el modelo: ${e.message}", Toast.LENGTH_LONG).show() } }
        }
    }
    private fun queryName(uri: Uri): String? { contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) return it.getString(0) }; return null }
    private fun formatBytes(bytes: Long): String { val gb = bytes / 1024.0 / 1024.0 / 1024.0; return if (gb >= 1) "%.2f GB".format(gb) else "%.0f MB".format(bytes / 1024.0 / 1024.0) }
    override fun onDestroy() { ioExecutor.shutdownNow(); super.onDestroy() }
}
