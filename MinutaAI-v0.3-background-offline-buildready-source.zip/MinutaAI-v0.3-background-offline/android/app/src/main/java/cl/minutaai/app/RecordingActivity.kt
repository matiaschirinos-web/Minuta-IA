package cl.minutaai.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordingActivity : AppCompatActivity() {
    private lateinit var activeStore: ActiveMeetingStore
    private lateinit var titleInput: EditText
    private lateinit var templateSpinner: Spinner
    private lateinit var recordButton: Button
    private lateinit var cancelButton: Button
    private lateinit var statusText: TextView
    private lateinit var timerText: TextView
    private lateinit var transcriptPreview: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var requestedStop = false
    private var startingService = false
    private var savedIdBeforeStop = ""

    private val uiTicker = object : Runnable {
        override fun run() {
            renderServiceState()
            handler.postDelayed(this, 500)
        }
    }

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) ensureNotificationPermissionThenStart()
        else Toast.makeText(
            this,
            "Necesito permiso de micrófono para transcribir la reunión.",
            Toast.LENGTH_LONG
        ).show()
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        // El permiso de notificaciones mejora la visibilidad del servicio, pero su rechazo
        // no debe borrar ni impedir una reunión iniciada conscientemente por el usuario.
        startBackgroundMeeting()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recording)
        activeStore = ActiveMeetingStore(this)
        titleInput = findViewById(R.id.titleInput)
        templateSpinner = findViewById(R.id.templateSpinner)
        recordButton = findViewById(R.id.recordButton)
        cancelButton = findViewById(R.id.cancelButton)
        statusText = findViewById(R.id.statusText)
        timerText = findViewById(R.id.timerText)
        transcriptPreview = findViewById(R.id.transcriptPreview)

        val templates = listOf("General", "Proyecto", "Técnica", "Cliente")
        templateSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, templates)
        titleInput.setText("Reunión ${SimpleDateFormat("dd-MM HH:mm", Locale.getDefault()).format(Date())}")

        recordButton.setOnClickListener {
            val state = activeStore.read()
            if (state.active) requestStopAndSave() else ensurePermissionsAndStart()
        }

        cancelButton.setOnClickListener {
            val state = activeStore.read()
            if (state.active) {
                startService(Intent(this, MeetingCaptureService::class.java).apply {
                    action = MeetingCaptureService.ACTION_CANCEL
                })
                Toast.makeText(this, "Reunión cancelada.", Toast.LENGTH_SHORT).show()
            }
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        activeStore.recoverIfStale()
        handler.removeCallbacks(uiTicker)
        handler.post(uiTicker)
    }

    override fun onPause() {
        handler.removeCallbacks(uiTicker)
        super.onPause()
    }

    private fun ensurePermissionsAndStart() {
        if (!OfflineSpeechController.isStrictOfflineAvailable(this)) {
            Toast.makeText(
                this,
                "Android no informa un reconocedor on-device. Esta versión no enviará audio a la nube como fallback.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            ensureNotificationPermissionThenStart()
        } else {
            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun ensureNotificationPermissionThenStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startBackgroundMeeting()
        }
    }

    private fun startBackgroundMeeting() {
        if (activeStore.read().active || startingService) return
        startingService = true
        requestedStop = false
        val intent = Intent(this, MeetingCaptureService::class.java).apply {
            action = MeetingCaptureService.ACTION_START
            putExtra(MeetingCaptureService.EXTRA_TITLE, titleInput.text.toString())
            putExtra(MeetingCaptureService.EXTRA_TEMPLATE, templateSpinner.selectedItem?.toString() ?: "General")
        }
        try {
            ContextCompat.startForegroundService(this, intent)
            statusText.text = "Iniciando servicio de micrófono… Puedes salir de la app cuando comience."
            recordButton.isEnabled = false
            handler.postDelayed({
                startingService = false
                renderServiceState()
            }, 900)
        } catch (e: Exception) {
            startingService = false
            recordButton.isEnabled = true
            Toast.makeText(this, "No se pudo iniciar el servicio: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestStopAndSave() {
        requestedStop = true
        savedIdBeforeStop = activeStore.lastSavedMeetingId()
        recordButton.isEnabled = false
        statusText.text = "Finalizando y guardando…"
        startService(Intent(this, MeetingCaptureService::class.java).apply {
            action = MeetingCaptureService.ACTION_STOP
        })
    }

    private fun renderServiceState() {
        val state = activeStore.read()
        if (state.active) {
            startingService = false
            titleInput.setTextIfChanged(state.title)
            selectTemplate(state.template)
            titleInput.isEnabled = false
            templateSpinner.isEnabled = false
            recordButton.isEnabled = true
            recordButton.text = "Finalizar y guardar"
            cancelButton.text = "Cancelar reunión"
            val elapsed = System.currentTimeMillis() - state.startedAt
            timerText.text = formatDuration(elapsed)
            statusText.text = "Segundo plano activo · ${state.status}\nPuedes bloquear la pantalla o cambiar de app."
            transcriptPreview.text = when {
                state.transcript.isBlank() && state.partial.isBlank() -> "La transcripción aparecerá aquí."
                state.partial.isBlank() -> state.transcript
                state.transcript.isBlank() -> "…${state.partial}"
                else -> "${state.transcript}\n…${state.partial}"
            }
            return
        }

        if (startingService) return

        titleInput.isEnabled = true
        templateSpinner.isEnabled = true
        recordButton.isEnabled = true
        recordButton.text = "Iniciar reunión en segundo plano"
        cancelButton.text = "Volver"
        timerText.text = "00:00"

        if (requestedStop) {
            val savedId = activeStore.lastSavedMeetingId()
            requestedStop = false
            if (savedId.isNotBlank() && savedId != savedIdBeforeStop) {
                startActivity(Intent(this, MeetingDetailActivity::class.java).apply {
                    putExtra("meeting_id", savedId)
                })
                finish()
                return
            }
            statusText.text = "La reunión terminó, pero no había texto suficiente para guardarla."
        } else {
            statusText.text = if (OfflineSpeechController.isStrictOfflineAvailable(this)) {
                "Reconocimiento local disponible · listo para iniciar"
            } else {
                "Reconocimiento local no disponible en este dispositivo"
            }
        }
    }

    private fun EditText.setTextIfChanged(value: String) {
        if (text.toString() != value) setText(value)
    }

    private fun selectTemplate(value: String) {
        val adapter = templateSpinner.adapter ?: return
        for (i in 0 until adapter.count) {
            if (adapter.getItem(i)?.toString() == value) {
                if (templateSpinner.selectedItemPosition != i) templateSpinner.setSelection(i)
                return
            }
        }
    }

    private fun formatDuration(ms: Long): String {
        val total = (ms / 1000).coerceAtLeast(0)
        return "%02d:%02d".format(total / 60, total % 60)
    }
}
