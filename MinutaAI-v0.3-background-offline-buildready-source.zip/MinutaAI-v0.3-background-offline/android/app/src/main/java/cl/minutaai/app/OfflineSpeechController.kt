package cl.minutaai.app

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

class OfflineSpeechController(
    private val context: Context,
    private val languageTag: String,
    private val onFinalText: (String) -> Unit,
    private val onPartialText: (String) -> Unit,
    private val onStatus: (String) -> Unit,
    private val onFatalError: (String) -> Unit,
) : RecognitionListener {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var running = false
    private var restarting = false
    private var lastFinal = ""

    companion object {
        fun isStrictOfflineAvailable(context: Context): Boolean =
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
    }

    fun start(): Boolean {
        if (!isStrictOfflineAvailable(context)) {
            onFatalError("Este teléfono no informa un reconocedor de voz on-device disponible.")
            return false
        }
        running = true
        createRecognizerIfNeeded()
        startListeningSoon(0)
        return true
    }

    fun stop() {
        running = false
        mainHandler.removeCallbacksAndMessages(null)
        try { recognizer?.stopListening() } catch (_: Exception) {}
        try { recognizer?.cancel() } catch (_: Exception) {}
        recognizer?.destroy()
        recognizer = null
        onPartialText("")
        onStatus("Detenido")
    }

    fun dispose() {
        running = false
        mainHandler.removeCallbacksAndMessages(null)
        try { recognizer?.cancel() } catch (_: Exception) {}
        recognizer?.destroy()
        recognizer = null
    }

    fun requestLanguageModelDownload() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        if (!isStrictOfflineAvailable(context)) return
        createRecognizerIfNeeded()
        try {
            recognizer?.triggerModelDownload(buildIntent())
            onStatus("Solicitud de descarga del idioma enviada al sistema.")
        } catch (e: Exception) {
            onFatalError("No se pudo solicitar el modelo de voz: ${e.message}")
        }
    }

    private fun createRecognizerIfNeeded() {
        if (recognizer != null) return
        recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(context).also {
            it.setRecognitionListener(this)
        }
    }

    private fun buildIntent(): Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            putExtra(RecognizerIntent.EXTRA_ENABLE_FORMATTING, RecognizerIntent.FORMATTING_OPTIMIZE_QUALITY)
        }
    }

    private fun startListeningSoon(delayMs: Long) {
        if (!running || restarting) return
        restarting = true
        mainHandler.postDelayed({
            restarting = false
            if (!running) return@postDelayed
            try {
                createRecognizerIfNeeded()
                onStatus("Escuchando…")
                recognizer?.startListening(buildIntent())
            } catch (e: Exception) {
                onFatalError("No se pudo iniciar el reconocimiento local: ${e.message}")
            }
        }, delayMs)
    }

    private fun restart(delayMs: Long = 250) {
        if (!running) return
        try { recognizer?.cancel() } catch (_: Exception) {}
        startListeningSoon(delayMs)
    }

    private fun bestText(results: Bundle?): String =
        results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull().orEmpty().trim()

    override fun onResults(results: Bundle?) {
        val text = bestText(results)
        onPartialText("")
        if (text.isNotBlank() && !isDuplicate(text)) {
            lastFinal = text
            onFinalText(text)
        }
        restart(150)
    }

    override fun onPartialResults(partialResults: Bundle?) {
        onPartialText(bestText(partialResults))
    }

    private fun isDuplicate(text: String): Boolean {
        val a = text.lowercase().replace(Regex("\\s+"), " ").trim()
        val b = lastFinal.lowercase().replace(Regex("\\s+"), " ").trim()
        return a.isNotBlank() && a == b
    }

    override fun onError(error: Int) {
        if (!running) return
        when (error) {
            SpeechRecognizer.ERROR_NO_MATCH,
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restart(150)
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> restart(700)
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                running = false
                onFatalError("Android quitó el permiso de micrófono.")
            }
            SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
            SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> {
                running = false
                onFatalError("El modelo on-device para $languageTag no está instalado. Ve a Ajustes y solicita su descarga.")
            }
            else -> restart(500)
        }
    }

    override fun onReadyForSpeech(params: Bundle?) { onStatus("Escuchando…") }
    override fun onBeginningOfSpeech() { onStatus("Detectando voz…") }
    override fun onEndOfSpeech() { onStatus("Procesando frase…") }
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit
    override fun onEvent(eventType: Int, params: Bundle?) = Unit
}
