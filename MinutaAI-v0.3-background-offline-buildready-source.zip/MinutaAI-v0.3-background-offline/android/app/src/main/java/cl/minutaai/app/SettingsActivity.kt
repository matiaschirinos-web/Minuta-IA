package cl.minutaai.app

import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.speech.SpeechRecognizer
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

class SettingsActivity : AppCompatActivity() {
    private lateinit var modelStatus: TextView
    private lateinit var speechStatus: TextView
    private lateinit var languageInput: EditText
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private var speechDownloadController: OfflineSpeechController? = null

    private val pickModel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importModel(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        modelStatus = findViewById(R.id.modelStatus)
        speechStatus = findViewById(R.id.speechStatus)
        languageInput = findViewById(R.id.languageInput)
        languageInput.setText(OfflineModelSettings.speechLanguage(this))

        renderStatus()

        findViewById<Button>(R.id.importModelButton).setOnClickListener {
            pickModel.launch(arrayOf("application/octet-stream", "*/*"))
        }
        findViewById<Button>(R.id.removeModelButton).setOnClickListener {
            val path = OfflineModelSettings.llmModelPath(this)
            if (path.isNotBlank()) File(path).delete()
            OfflineModelSettings.setLlmModelPath(this, "")
            renderStatus()
            Toast.makeText(this, "Modelo local eliminado.", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.downloadSpeechModelButton).setOnClickListener {
            requestSpeechModelDownload()
        }
        findViewById<Button>(R.id.saveSettingsButton).setOnClickListener {
            OfflineModelSettings.setSpeechLanguage(this, languageInput.text.toString())
            Toast.makeText(this, "Ajustes guardados.", Toast.LENGTH_SHORT).show()
            renderStatus()
        }
    }

    private fun renderStatus() {
        val path = OfflineModelSettings.llmModelPath(this)
        modelStatus.text = if (OfflineModelSettings.hasLlmModel(this)) {
            val file = File(path)
            "IA local instalada: ${file.name} (${formatBytes(file.length())})"
        } else {
            "Sin modelo generativo. La app usará reglas locales para crear la minuta."
        }

        speechStatus.text = when {
            Build.VERSION.SDK_INT < Build.VERSION_CODES.S -> "Android demasiado antiguo para forzar reconocimiento estrictamente on-device."
            SpeechRecognizer.isOnDeviceRecognitionAvailable(this) -> "Reconocimiento de voz on-device disponible."
            else -> "Android no informa un reconocedor de voz on-device disponible."
        }
    }

    private fun importModel(uri: Uri) {
        modelStatus.text = "Importando modelo…"
        ioExecutor.execute {
            try {
                val dir = File(filesDir, "models/llm").apply { mkdirs() }
                val displayName = queryName(uri) ?: "model.task"
                val extension = displayName.substringAfterLast('.', "task")
                val target = File(dir, "minuta_model.$extension")
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "No pude abrir el archivo" }
                    FileOutputStream(target).use { output -> input.copyTo(output, 1024 * 1024) }
                }
                OfflineModelSettings.setLlmModelPath(this, target.absolutePath)
                runOnUiThread {
                    renderStatus()
                    Toast.makeText(this, "Modelo importado. Todo el resumen puede ejecutarse localmente.", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    renderStatus()
                    Toast.makeText(this, "No pude importar el modelo: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun requestSpeechModelDownload() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU || !OfflineSpeechController.isStrictOfflineAvailable(this)) {
            Toast.makeText(this, "Este dispositivo no permite solicitar el modelo on-device desde la app.", Toast.LENGTH_LONG).show()
            return
        }
        speechDownloadController?.dispose()
        val controller = OfflineSpeechController(
            context = this,
            languageTag = languageInput.text.toString().trim().ifBlank { OfflineModelSettings.DEFAULT_LANGUAGE },
            onFinalText = {}, onPartialText = {},
            onStatus = { Toast.makeText(this, it, Toast.LENGTH_LONG).show() },
            onFatalError = { Toast.makeText(this, it, Toast.LENGTH_LONG).show() }
        )
        speechDownloadController = controller
        controller.requestLanguageModelDownload()
        // El sistema gestiona la descarga; mantenemos el objeto mientras esta pantalla exista.
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        return null
    }

    private fun formatBytes(bytes: Long): String {
        val gb = bytes / 1024.0 / 1024.0 / 1024.0
        return if (gb >= 1) "%.2f GB".format(gb) else "%.0f MB".format(bytes / 1024.0 / 1024.0)
    }

    override fun onDestroy() {
        speechDownloadController?.dispose()
        speechDownloadController = null
        ioExecutor.shutdownNow()
        super.onDestroy()
    }
}
