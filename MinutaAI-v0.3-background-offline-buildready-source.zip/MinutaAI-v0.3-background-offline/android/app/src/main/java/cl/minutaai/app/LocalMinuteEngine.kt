package cl.minutaai.app

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

class LocalMinuteEngine(private val context: Context) {
    data class Result(val minutes: String, val engineName: String)

    fun generate(meeting: Meeting): Result {
        val transcript = meeting.transcript.trim()
        if (transcript.isBlank()) {
            return Result("No hay transcripción para resumir.", "Sin transcripción")
        }

        val modelPath = OfflineModelSettings.llmModelPath(context)
        if (modelPath.isBlank() || !File(modelPath).isFile) {
            return Result(HeuristicMinuteBuilder.build(transcript, meeting.template), "Reglas locales")
        }

        return try {
            Result(generateWithLlm(modelPath, transcript, meeting.template), "IA local")
        } catch (e: Exception) {
            val fallback = HeuristicMinuteBuilder.build(transcript, meeting.template)
            Result(
                "$fallback\n\n> La IA local no pudo ejecutarse (${e.message ?: "error desconocido"}); se usó el modo de reglas.",
                "Reglas locales (fallback)"
            )
        }
    }

    private fun generateWithLlm(modelPath: String, transcript: String, template: String): String {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelPath)
            .setMaxTokens(4096)
            .setTopK(20)
            .setTemperature(0.2f)
            .setRandomSeed(42)
            .build()

        LlmInference.createFromOptions(context, options).use { llm ->
            val chunks = chunkTranscript(transcript, 7000)
            val notes = chunks.mapIndexed { index, chunk ->
                val prompt = """
                    Eres un asistente de minutas. Extrae hechos de una transcripción de reunión.
                    No inventes responsables, fechas ni decisiones. Si una frase expresa una posibilidad
                    (por ejemplo: \"podríamos\", \"quizás\", \"sería bueno\"), NO la conviertas en compromiso confirmado.
                    Devuelve texto breve en español con estas secciones: Hechos, Decisiones explícitas,
                    Tareas explícitas, Compromisos por confirmar, Pendientes y Riesgos.

                    Plantilla: $template
                    Fragmento ${index + 1}/${chunks.size}:
                    $chunk
                """.trimIndent()
                llm.generateResponse(prompt)
            }

            var combined = notes.joinToString("\n\n---\n\n")
            while (combined.length > 9000) {
                val reduced = chunkTranscript(combined, 7000).map { group ->
                    llm.generateResponse(
                        """
                        Condensa estas notas de reunión conservando únicamente hechos verificables,
                        decisiones explícitas, tareas explícitas, compromisos por confirmar, pendientes
                        y riesgos. No inventes datos. Elimina duplicados.

                        $group
                        """.trimIndent()
                    )
                }
                combined = reduced.joinToString("\n\n---\n\n")
            }

            val finalPrompt = """
                Convierte las notas siguientes en una minuta profesional en español.
                Reglas obligatorias:
                1. No inventes información ausente.
                2. Separa \"Decisiones\" de \"Compromisos por confirmar\".
                3. Solo asigna responsable si fue explícito.
                4. Si no hay fecha explícita, escribe \"Sin fecha definida\".
                5. Si dos fragmentos repiten lo mismo, fusiónalos.
                6. Usa estas secciones: Resumen ejecutivo, Decisiones, Tareas y responsables,
                   Compromisos por confirmar, Pendientes, Riesgos/Bloqueos, Próximos pasos.
                7. No agregues comentarios sobre tu proceso.

                Tipo de reunión: $template

                Notas extraídas:
                $combined
            """.trimIndent()

            return llm.generateResponse(finalPrompt).trim()
                .ifBlank { HeuristicMinuteBuilder.build(transcript, template) }
        }
    }

    private fun chunkTranscript(text: String, maxChars: Int): List<String> {
        if (text.length <= maxChars) return listOf(text)
        val chunks = mutableListOf<String>()
        var start = 0
        while (start < text.length) {
            var end = (start + maxChars).coerceAtMost(text.length)
            if (end < text.length) {
                val boundary = text.lastIndexOfAny(charArrayOf('.', '?', '!', '\n'), end)
                if (boundary > start + maxChars / 2) end = boundary + 1
            }
            chunks += text.substring(start, end).trim()
            start = end
        }
        return chunks.filter { it.isNotBlank() }
    }
}
