plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "cl.minutaai.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "cl.minutaai.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "0.3.0-background-offline"
    }

    buildFeatures {
        viewBinding = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources.excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.code.gson:gson:2.11.0")

    // IA generativa local. No usa API ni servidor: el modelo .task vive en el teléfono.
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
}
