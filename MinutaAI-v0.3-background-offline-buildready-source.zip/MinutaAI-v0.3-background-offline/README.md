# Minuta AI Offline v0.3 — segundo plano

Aplicación Android para transcribir conversaciones y generar minutas **sin API, sin backend, sin claves y sin permiso INTERNET**.

## Cambio principal de esta versión

La reunión ya no depende de que `RecordingActivity` permanezca visible. Al pulsar **Iniciar reunión en segundo plano**, la app crea un **Foreground Service de tipo `microphone`** y muestra una notificación permanente.

Mientras la reunión siga activa puedes:

- bloquear la pantalla;
- volver al inicio;
- abrir WhatsApp, Teams u otra aplicación;
- apagar la pantalla;
- volver después a Minuta AI y ver la transcripción acumulada.

La notificación muestra **Reunión en curso** y permite **Finalizar** sin volver a abrir la app.

## Qué hace

- Transcripción on-device con `SpeechRecognizer.createOnDeviceSpeechRecognizer()`.
- Idioma por defecto: `es-CL`.
- Foreground Service de micrófono para continuar en segundo plano.
- `PARTIAL_WAKE_LOCK` mientras existe una reunión activa para mantener el procesamiento con pantalla apagada.
- Estado y transcripción parcial guardados en almacenamiento privado después de cada fragmento final.
- Recuperación automática de una reunión si Android mata anormalmente el proceso y quedó una captura huérfana.
- Historial local de reuniones.
- Minutas editables y compartibles.
- Minuta local por reglas, sin descargar un LLM.
- IA local opcional mediante modelo `.task` compatible con MediaPipe LLM Inference.
- Sin permiso `INTERNET`.

## Restricción de Android que no se puede eliminar

En Android moderno, un servicio de micrófono no puede comenzar arbitrariamente cuando la aplicación ya está en segundo plano. Por eso debes pulsar **Iniciar reunión** mientras la pantalla de Minuta AI está visible y el permiso de micrófono está concedido.

Una vez iniciado el Foreground Service, la reunión puede seguir con la aplicación fuera de pantalla.

Tampoco existe una forma legítima de sobrevivir a:

- **Forzar detención** desde Ajustes;
- reiniciar/apagar el teléfono;
- revocar el permiso de micrófono;
- matar deliberadamente el proceso mediante herramientas del sistema/OEM.

La app usa `START_NOT_STICKY`: si Android destruye el servicio, no intenta arrancar de nuevo el micrófono a escondidas desde el fondo, porque Android 14+ restringe ese comportamiento. En cambio, conserva el último texto confirmado y puede recuperarlo al volver a abrir la app.

## Permisos

La app declara:

- `RECORD_AUDIO`
- `FOREGROUND_SERVICE`
- `FOREGROUND_SERVICE_MICROPHONE`
- `WAKE_LOCK`
- `POST_NOTIFICATIONS`

No declara `INTERNET`.

En Android 13+ se solicita permiso de notificaciones para que la reunión en curso sea claramente visible. Negarlo no convierte la app en una app de nube ni agrega Internet, pero puede reducir la visibilidad de la notificación según la versión de Android.

## Abrir el proyecto

1. Instala Android Studio reciente.
2. Abre la carpeta `android/` como proyecto.
3. Espera el Gradle Sync.
4. Conecta un teléfono Android, idealmente Android 12 o superior.
5. Ejecuta `app`.

El proyecto usa `compileSdk 35`, `targetSdk 35` y `minSdk 26`.

## Preparar reconocimiento español de Chile

1. Abre **Ajustes** dentro de Minuta AI.
2. Deja el idioma en `es-CL`.
3. Pulsa **Solicitar modelo de voz al sistema**.
4. Si Android ofrece una descarga de voz offline, complétala.

La app usa explícitamente `createOnDeviceSpeechRecognizer`; no cambia silenciosamente a reconocimiento de red.

## Flujo de uso

1. Abre **Nueva reunión**.
2. Escribe nombre y plantilla.
3. Pulsa **Iniciar reunión en segundo plano**.
4. Concede micrófono y notificaciones cuando Android lo solicite.
5. Cuando aparezca `Segundo plano activo`, puedes salir o bloquear el teléfono.
6. Para terminar:
   - vuelve a la app y pulsa **Finalizar y guardar**, o
   - pulsa **Finalizar** desde la notificación.
7. La reunión queda en el historial.
8. Abre la reunión y genera la minuta local.

## Arquitectura

- `MeetingCaptureService.kt`: Foreground Service de micrófono y ciclo de vida de la reunión.
- `ActiveMeetingState.kt`: estado persistible de la captura activa.
- `ActiveMeetingStore.kt`: checkpoint local y recuperación de capturas interrumpidas.
- `RecordingActivity.kt`: inicia/detiene el servicio y muestra su estado; ya no posee el micrófono.
- `OfflineSpeechController.kt`: reconocimiento on-device y reinicio automático por segmentos.
- `MeetingRepository.kt`: historial privado local.
- `HeuristicMinuteBuilder.kt`: minuta sin LLM.
- `LocalMinuteEngine.kt`: IA local opcional + fallback por reglas.
- `SettingsActivity.kt`: idioma y modelo local.

## Casos límite contemplados

- La actividad puede destruirse sin detener la reunión.
- `stopWithTask=false`: quitar la tarea de la vista de recientes no ordena detener el servicio.
- La transcripción se escribe a disco después de cada resultado final.
- Un `wake lock` parcial mantiene la CPU disponible con pantalla apagada.
- El reconocedor se reinicia tras silencios, timeout o resultados finales.
- Si falla el reconocimiento después de haber producido texto, se conserva y guarda lo obtenido.
- Si el proceso desaparece anormalmente, un heartbeat permite detectar la captura huérfana y rescatar el texto confirmado.
- El generador de minuta no convierte automáticamente expresiones como “quizás” o “podríamos” en compromisos confirmados.

## Limitación técnica todavía presente

Esta versión depende del motor `SpeechRecognizer` on-device que entregue el fabricante/Android. El Foreground Service mantiene el proceso y el derecho de uso del micrófono en segundo plano, pero la calidad y duración efectiva de sesiones muy largas todavía deben probarse en el teléfono real.

Para una versión posterior de máxima robustez, el siguiente salto sería sustituir `SpeechRecognizer` por un ASR propio (por ejemplo sherpa-onnx) alimentado directamente desde `AudioRecord`, lo que daría control completo sobre sesiones de varias horas y diarización.

## Compilar APK con GitHub Actions

Este proyecto incluye `.github/workflows/build-apk.yml`.

Al subir el proyecto a un repositorio GitHub, el workflow instala JDK 17, Android SDK 35, Build Tools 35.0.1 y Gradle 8.9, ejecuta `assembleDebug` y publica `app-debug.apk` como artifact llamado `MinutaAI-v0.3-debug-apk`.

También puede ejecutarse manualmente desde **Actions → Build Android APK → Run workflow**.
