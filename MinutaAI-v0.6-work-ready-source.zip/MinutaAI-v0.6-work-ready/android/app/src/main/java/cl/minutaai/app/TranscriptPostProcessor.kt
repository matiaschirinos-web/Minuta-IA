package cl.minutaai.app

import java.text.Normalizer

/** Corrección conservadora de nombres/términos declarados por el usuario. */
object TranscriptPostProcessor {
    fun refine(raw: String, participants: String, glossary: String): String {
        var text = raw.trim().replace(Regex("[ \\t]+"), " ")
        if (text.isBlank()) return text

        val participantTerms = parseTerms(participants)
        val glossaryTerms = parseTerms(glossary)
        val preferred = participantTerms + glossaryTerms
        val tokenPattern = Regex("(?iu)(?<![\\p{L}\\p{N}])([\\p{L}\\p{N}ÁÉÍÓÚÜÑáéíóúüñ-]+)(?![\\p{L}\\p{N}])")

        participantTerms.filter { !it.contains(' ') && it.length >= 3 }.forEach { target ->
            text = tokenPattern.replace(text) { match ->
                val candidate = match.groupValues[1]
                if (shouldReplace(candidate, target, aggressive = false)) target else candidate
            }
        }
        glossaryTerms.filter { !it.contains(' ') && it.length >= 3 }.forEach { target ->
            text = tokenPattern.replace(text) { match ->
                val candidate = match.groupValues[1]
                if (shouldReplace(candidate, target, aggressive = true)) target else candidate
            }
        }

        preferred.filter { it.contains(' ') }.forEach { phrase ->
            val escaped = phrase.split(Regex("\\s+")).joinToString("\\s+") { Regex.escape(it) }
            text = Regex("(?iu)(?<![\\p{L}\\p{N}])$escaped(?![\\p{L}\\p{N}])").replace(text, phrase)
        }
        return text.trim()
    }

    fun parseTerms(csv: String): List<String> = csv
        .split(',', ';', '\n')
        .map { it.trim() }
        .filter { it.length >= 2 }
        .distinctBy { normalize(it) }

    fun mentionedKnownNames(text: String, participants: String, glossary: String): List<String> {
        val haystack = normalize(text)
        return (parseTerms(participants) + parseTerms(glossary))
            .filter { normalize(it) in haystack }
            .distinctBy { normalize(it) }
    }

    fun candidateProperNames(text: String): List<String> {
        if (text.isBlank()) return emptyList()
        val stop = setOf(
            "La", "El", "Los", "Las", "Un", "Una", "Y", "O", "Pero", "Porque", "Entonces",
            "Bueno", "Bien", "Sí", "Si", "No", "También", "Despues", "Después", "Hoy", "Mañana",
            "Ahora", "Esto", "Eso", "Este", "Esta", "Como", "Cuando", "Donde", "Para", "Por"
        )
        val regex = Regex("\\b[A-ZÁÉÍÓÚÜÑ][a-záéíóúüñ]{2,}(?:\\s+[A-ZÁÉÍÓÚÜÑ][a-záéíóúüñ]{2,}){0,2}\\b")
        return regex.findAll(text).mapNotNull { m ->
            val value = m.value.trim()
            val previous = text.substring(0, m.range.first).trimEnd().lastOrNull()
            val sentenceStart = m.range.first == 0 || previous == '.' || previous == '!' || previous == '?'
            if ((sentenceStart && !value.contains(' ')) || value in stop) null else value
        }.distinctBy { normalize(it) }.take(12).toList()
    }

    private fun shouldReplace(candidate: String, target: String, aggressive: Boolean): Boolean {
        val a = normalize(candidate)
        val b = normalize(target)
        if (a == b) return candidate != target
        if (a.length < 3 || b.length < 3) return false
        if (kotlin.math.abs(a.length - b.length) > maxDistance(b.length)) return false
        val distance = levenshtein(a, b)
        val firstDiff = a.firstOrNull() != b.firstOrNull()
        val limit = when {
            !firstDiff -> maxDistance(b.length)
            aggressive && b.length >= 6 -> maxDistance(b.length)
            else -> maxDistance(b.length) - 1
        }
        return limit >= 1 && distance <= limit
    }

    private fun maxDistance(length: Int): Int = when {
        length <= 5 -> 1
        length <= 9 -> 2
        else -> 3
    }

    private fun normalize(value: String): String {
        val decomposed = Normalizer.normalize(value.lowercase(), Normalizer.Form.NFD)
        return decomposed.replace(Regex("\\p{M}+"), "")
            .replace(Regex("[^a-z0-9 ]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)
        for (i in a.indices) {
            current[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                current[j + 1] = minOf(current[j] + 1, previous[j + 1] + 1, previous[j] + cost)
            }
            val swap = previous
            previous = current
            current = swap
        }
        return previous[b.length]
    }
}
