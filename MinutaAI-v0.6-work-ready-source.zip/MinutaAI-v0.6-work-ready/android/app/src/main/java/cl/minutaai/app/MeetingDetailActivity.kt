package cl.minutaai.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.IntentCompat
import kotlinx.coroutines.runBlocking
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.Executors

class MeetingDetailActivity : AppCompatActivity() {
    private lateinit var repo: MeetingRepository
    private lateinit var meeting: Meeting
    private lateinit var minutesInput: EditText
    private lateinit var transcriptInput: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var processButton: Button
    private lateinit var reprocessButton: Button
    private lateinit var engineText: TextView
    private lateinit var reviewText: TextView
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_detail); repo = MeetingRepository(this)
        val loaded = intent.getStringExtra("meeting_id")?.let { repo.get(it) }
        if (loaded == null) { Toast.makeText(this, "No encuentro esa reunión.", Toast.LENGTH_LONG).show(); finish(); return }
        meeting = loaded
        findViewById<TextView>(R.id.titleText).text = meeting.title
        findViewById<TextView>(R.id.metaText).text = buildString {
            append(DateFormat.getDateTimeInstance().format(Date(meeting.createdAt))); append(" · ${formatDuration(meeting.durationMs)} · ${meeting.template}")
            if (meeting.participants.isNotBlank()) append("
Participantes: ${meeting.participants}")
            if (meeting.transcriptEngine.isNotBlank()) append("
Transcripción: ${meeting.transcriptEngine}")
        }
        minutesInput = findViewById(R.id.minutesInput); transcriptInput = findViewById(R.id.transcriptInput); progressBar = findViewById(R.id.progressBar); processButton = findViewById(R.id.processButton); reprocessButton = findViewById(R.id.reprocessButton); engineText = findViewById(R.id.engineText); reviewText = findViewById(R.id.reviewText)
        minutesInput.setText(meeting.minutes); transcriptInput.setText(meeting.transcript); renderState()
        processButton.setOnClickListener { generateMinutes() }
        reprocessButton.setOnClickListener { reprocessRecoveredAudio() }
        findViewById<Button>(R.id.saveButton).setOnClickListener { saveEdits(true) }
        findViewById<Button>(R.id.shareButton).setOnClickListener { saveEdits(false); shareText() }
        findViewById<Button>(R.id.pdfButton).setOnClickListener { saveEdits(false); shareFile(ExportManager.exportPdf(this, meeting), "application/pdf") }
        findViewById<Button>(R.id.docxButton).setOnClickListener { saveEdits(false); shareFile(ExportManager.exportDocx(this, meeting), "application/vnd.openxmlformats-officedocument.wordprocessingml.document") }
    }

    private fun renderState() {
        engineText.text = if (meeting.minuteEngine.isBlank()) "Minuta aún no generada" else "Motor de minuta: ${meeting.minuteEngine}"
        reviewText.text = if (meeting.transcriptReviewedAt > 0) "✓ Transcripción marcada como revisada. Puedes regenerar la minuta si haces cambios." else "1) Revisa/corrige la transcripción. 2) Pulsa Generar minuta. Las decisiones se extraerán solo desde este texto."
        reprocessButton.visibility = if (meeting.audioPath.isNotBlank() && File(meeting.audioPath).isFile) View.VISIBLE else View.GONE
    }

    private fun generateMinutes() {
        meeting.transcript = transcriptInput.text.toString().trim()
        if (meeting.transcript.isBlank()) { Toast.makeText(this, "La transcripción está vacía.", Toast.LENGTH_LONG).show(); return }
        meeting.transcriptReviewedAt = System.currentTimeMillis(); repo.save(meeting); setProcessing(true, "Generando minuta desde texto revisado…")
        executor.execute {
            val result = LocalMinuteEngine(applicationContext).generate(meeting)
            runOnUiThread { meeting.minutes = result.minutes; meeting.minuteEngine = result.engineName; repo.save(meeting); minutesInput.setText(result.minutes); renderState(); setProcessing(false); Toast.makeText(this, "Minuta generada desde la transcripción revisada.", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun reprocessRecoveredAudio() {
        val audio = File(meeting.audioPath); if (!audio.isFile) { renderState(); return }
        setProcessing(true, "Reprocesando audio recuperado con Whisper…")
        executor.execute {
            try {
                val result = runBlocking { WhisperTranscriber(applicationContext).transcribe(audio, meeting.participants, meeting.glossary) }
                meeting.transcript = result.text; meeting.transcriptEngine = result.engine; meeting.transcriptReviewedAt = 0L; repo.save(meeting)
                if (!OfflineModelSettings.keepAudio(applicationContext)) { audio.delete(); meeting.audioPath = ""; repo.save(meeting) }
                runOnUiThread { transcriptInput.setText(meeting.transcript); renderState(); setProcessing(false); Toast.makeText(this, "Audio recuperado reprocesado. Revisa el texto antes de minutar.", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) { runOnUiThread { setProcessing(false); Toast.makeText(this, "No pude reprocesar el audio: ${e.message}", Toast.LENGTH_LONG).show() } }
        }
    }

    private fun setProcessing(value: Boolean, label: String = "") { progressBar.visibility = if (value) View.VISIBLE else View.GONE; processButton.isEnabled = !value; reprocessButton.isEnabled = !value; processButton.text = if (value && label.isNotBlank()) label else "Generar minuta desde transcripción revisada" }
    private fun saveEdits(showToast: Boolean) { meeting.minutes = minutesInput.text.toString(); val newTranscript = transcriptInput.text.toString(); if (newTranscript != meeting.transcript) meeting.transcriptReviewedAt = 0L; meeting.transcript = newTranscript; repo.save(meeting); renderState(); if (showToast) Toast.makeText(this, "Cambios guardados.", Toast.LENGTH_SHORT).show() }
    private fun shareText() { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "Minuta - ${meeting.title}"); putExtra(Intent.EXTRA_TEXT, "${meeting.title}

${meeting.minutes}") }, "Compartir minuta")) }
    private fun shareFile(file: File, mime: String) { val uri = ExportManager.uri(this, file); startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "Exportar minuta")) }
    override fun onDestroy() { executor.shutdownNow(); super.onDestroy() }
    private fun formatDuration(ms: Long): String { val total = ms / 1000; return "%02d:%02d".format(total / 60, total % 60) }
}
