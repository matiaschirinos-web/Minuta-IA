package cl.minutaai.app

import java.text.Normalizer

object HeuristicMinuteBuilder {
    private val decisionHints = listOf("se decidió", "decidimos", "acordamos", "queda acordado", "aprobado", "definimos", "quedamos en")
    private val taskHints = listOf("me encargo", "se encargará", "voy a", "vamos a", "deberá", "debe", "hay que", "enviar", "preparar", "entregar", "coordinar", "confirmar", "actualizar", "probar")
    private val uncertainHints = listOf("podríamos", "podriamos", "quizás", "quizas", "tal vez", "sería bueno", "seria bueno", "se podría", "se podria", "podemos evaluar", "podemos revisar")
    private val pendingHints = listOf("pendiente", "falta", "por confirmar", "revisar", "validar", "averiguar", "consultar")
    private val riskHints = listOf("riesgo", "bloqueo", "bloqueado", "retraso", "problema", "impacto", "dependencia")
    private val conclusionHints = listOf("en conclusión", "en resumen", "finalmente", "entonces quedamos", "para cerrar", "como conclusión")
    private val stopWords = setOf("para", "como", "pero", "porque", "esta", "este", "esto", "estos", "estas", "entre", "desde", "hasta", "sobre", "todo", "toda", "todos", "todas", "cuando", "donde", "quien", "quienes", "unos", "unas", "tambien", "muy", "que", "con", "sin", "por", "del", "las", "los", "una", "uno", "de", "la", "el", "en", "se", "es", "un", "al")

    fun build(meeting: Meeting): String {
        val cleaned = meeting.transcript.trim()
        if (cleaned.isBlank()) return "No hay transcripción suficiente para generar una minuta."
        val sentences = sentences(cleaned)
        val uncertain = pick(sentences, uncertainHints)
        val decisions = pick(sentences, decisionHints).filterNot { it in uncertain }
        val tasks = pick(sentences, taskHints).filterNot { it in uncertain }
        val pending = pick(sentences, pendingHints).filterNot { it in uncertain || it in decisions || it in tasks }
        val risks = pick(sentences, riskHints).filterNot { it in uncertain }
        val conclusions = pick(sentences, conclusionHints).ifEmpty { decisions.takeLast(3) }
        val topics = topTopics(sentences, 7)
        val summary = extractiveSummary(sentences, 6)
        val declaredParticipants = TranscriptPostProcessor.parseTerms(meeting.participants)
        val mentioned = TranscriptPostProcessor.mentionedKnownNames(cleaned, meeting.participants, meeting.glossary)
            .filterNot { known -> declaredParticipants.any { same(it, known) } }
        val properNames = TranscriptPostProcessor.candidateProperNames(cleaned)
            .filterNot { candidate -> declaredParticipants.any { same(it, candidate) } }
            .filterNot { candidate -> mentioned.any { same(it, candidate) } }

        return buildString {
            appendLine("# Minuta profesional — ${meeting.title}")
            appendLine()
            appendLine("## Resumen ejecutivo")
            appendLine(summary.ifBlank { stripTimestamps(cleaned).take(1600) })
            appendLine()
            appendLine("## Participantes")
            if (declaredParticipants.isEmpty()) appendLine("- No informados antes de la reunión.") else declaredParticipants.forEach { appendLine("- $it") }
            if (mentioned.isNotEmpty()) appendLine("- Nombres conocidos mencionados: ${mentioned.joinToString(", ")}")
            if (properNames.isNotEmpty()) appendLine("- Posibles nombres detectados — revisar: ${properNames.joinToString(", ")}")
            appendLine()
            appendLine("## Temas tratados")
            if (topics.isEmpty()) appendLine("- No se pudieron aislar temas con suficiente claridad.") else topics.forEach { appendLine("- $it") }
            appendLine()
            appendSection("Decisiones confirmadas", decisions, "Alta: frase con indicador explícito de decisión")
            appendSection("Tareas y responsables", tasks, "Media: revisar responsable y fecha en la transcripción")
            appendSection("Propuestas / compromisos por confirmar", uncertain, "Media: no tratado como acuerdo")
            appendSection("Pendientes", pending, "Media")
            appendSection("Riesgos / bloqueos", risks, "Media")
            appendSection("Conclusiones explícitas", conclusions, "Alta si la propia conversación las formula como conclusión")
            appendLine("## Próximos pasos")
            val next = (tasks + pending).distinct().take(10)
            if (next.isEmpty()) appendLine("- No se detectaron próximos pasos explícitos.") else next.forEach { appendLine("- $it") }
            appendLine()
            appendLine("> Control de calidad: esta minuta se genera desde la transcripción revisada. Una propuesta no se convierte automáticamente en decisión. Los timestamps permiten volver al punto de la conversación.")
        }.trim()
    }

    private fun sentences(text: String): List<String> = text
        .split(Regex("""(?=\[[0-9]{2}:[0-9]{2}(?::[0-9]{2})?\])|(?<=[.!?])\s+|\n+"""))
        .map { it.trim() }.filter { stripTimestamps(it).length >= 10 }

    private fun topTopics(sentences: List<String>, limit: Int): List<String> {
        val freq = mutableMapOf<String, Int>()
        sentences.flatMap { tokens(stripTimestamps(it)) }.filter { it.length > 4 && it !in stopWords }.forEach { freq[it] = (freq[it] ?: 0) + 1 }
        return freq.entries.sortedByDescending { it.value }.filter { it.value >= 2 }.take(limit).map { it.key.replaceFirstChar { c -> c.uppercase() } }
    }

    private fun extractiveSummary(sentences: List<String>, limit: Int): String {
        if (sentences.size <= limit) return sentences.joinToString(" ")
        val frequencies = mutableMapOf<String, Int>()
        sentences.forEach { sentence -> tokens(stripTimestamps(sentence)).filter { it.length > 3 && it !in stopWords }.forEach { frequencies[it] = (frequencies[it] ?: 0) + 1 } }
        return sentences.mapIndexed { index, sentence ->
            val words = tokens(stripTimestamps(sentence)).filter { it.length > 3 && it !in stopWords }
            val lexical = if (words.isEmpty()) 0.0 else words.sumOf { (frequencies[it] ?: 0).toDouble() } / words.size
            val boost = when { containsAny(sentence, decisionHints) -> 2.0; containsAny(sentence, taskHints) -> 1.4; containsAny(sentence, pendingHints) -> 0.8; else -> 0.0 }
            Triple(index, sentence, lexical + boost)
        }.sortedByDescending { it.third }.take(limit).sortedBy { it.first }.joinToString(" ") { it.second }
    }

    private fun stripTimestamps(value: String) = value.replace(Regex("""\[[0-9]{2}:[0-9]{2}(?::[0-9]{2})?\]"""), "").trim()
    private fun tokens(value: String): List<String> = normalize(value).split(' ').filter { it.isNotBlank() }
    private fun normalize(value: String): String = Normalizer.normalize(value.lowercase(), Normalizer.Form.NFD).replace(Regex("""\p{M}+"""), "").replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("""\s+"""), " ").trim()
    private fun pick(sentences: List<String>, hints: List<String>): List<String> = sentences.filter { containsAny(it, hints) }.distinct().take(14)
    private fun containsAny(sentence: String, hints: List<String>): Boolean { val s = normalize(sentence); return hints.any { normalize(it) in s } }
    private fun same(a: String, b: String) = normalize(a) == normalize(b)
    private fun StringBuilder.appendSection(title: String, items: List<String>, confidence: String) {
        appendLine("## $title")
        if (items.isEmpty()) appendLine("- No detectado con suficiente certeza.") else items.forEach { appendLine("- ${it.trim()}") }
        appendLine("_Confianza: $confidence._")
        appendLine()
    }
}
