package cl.minutaai.app

import android.content.Context

class KnowledgeStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("meeting_knowledge", Context.MODE_PRIVATE)

    fun globalGlossary(): String = prefs.getString("global_glossary", "").orEmpty()
    fun recentParticipants(): String = prefs.getString("recent_participants", "").orEmpty()

    fun setGlobalGlossary(value: String) {
        prefs.edit().putString("global_glossary", normalizeList(value)).apply()
    }

    fun remember(participants: String, glossary: String) {
        val participantMerged = merge(recentParticipants(), participants).take(40).joinToString(", ")
        val glossaryMerged = merge(globalGlossary(), glossary).take(120).joinToString(", ")
        prefs.edit()
            .putString("recent_participants", participantMerged)
            .putString("global_glossary", glossaryMerged)
            .apply()
    }

    private fun merge(a: String, b: String): List<String> {
        val seen = linkedMapOf<String, String>()
        TranscriptPostProcessor.parseTerms("$a,$b").forEach { term ->
            val key = term.lowercase().trim()
            if (key.isNotBlank() && !seen.containsKey(key)) seen[key] = term.trim()
        }
        return seen.values.toList()
    }

    private fun normalizeList(value: String): String = merge("", value).joinToString(", ")
}
