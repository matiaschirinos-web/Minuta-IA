package cl.minutaai.app

import android.content.Context
import java.io.File

object OfflineModelSettings {
    private const val PREFS = "minuta_ai_offline_settings"
    private const val KEY_LLM_PATH = "llm_model_path"
    private const val KEY_KEEP_AUDIO = "keep_audio"

    fun llmModelPath(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LLM_PATH, "").orEmpty()

    fun setLlmModelPath(context: Context, path: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_LLM_PATH, path).apply()
    }

    fun hasLlmModel(context: Context): Boolean {
        val path = llmModelPath(context)
        return path.isNotBlank() && File(path).isFile && File(path).length() > 0
    }

    fun keepAudio(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_KEEP_AUDIO, false)

    fun setKeepAudio(context: Context, keep: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_KEEP_AUDIO, keep).apply()
    }
}
