package cl.minutaai.app

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream
import kotlin.math.max

/** Un único AudioRecord alimenta Vosk y el WAV temporal para Whisper. */
class VoskSpeechController(
    context: Context,
    private val audioFile: File,
    private val participants: String,
    private val glossary: String,
    private val onFinalText: (String) -> Unit,
    private val onPartialText: (String) -> Unit,
    private val onStatus: (String) -> Unit,
    private val onFatalError: (String) -> Unit,
) {
    companion object {
        const val MODEL_ASSET = "vosk-model-small-es-0.42.zip"
        const val MODEL_DIR = "vosk-model-small-es-0.42"
        private const val SAMPLE_RATE = 16_000
    }

    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var running = false
    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var recorder: AudioRecord? = null
    private var captureFuture: Future<*>? = null
    private var lastFinal = ""

    fun start(): Boolean {
        if (running) return true
        running = true
        dispatchStatus("Preparando Vosk y grabación local…")
        captureFuture = executor.submit {
            try {
                val modelDir = ensureModelExtracted()
                if (!running) return@submit
                model = Model(modelDir.absolutePath)
                recognizer = Recognizer(model, SAMPLE_RATE.toFloat()).apply {
                    setWords(true)
                    setPartialWords(false)
                }
                captureLoop()
            } catch (e: Exception) {
                dispatchFatal("No se pudo iniciar el micrófono local: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                cleanupNative()
            }
        }
        return true
    }

    @SuppressLint("MissingPermission")
    private fun captureLoop() {
        val minBuffer = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuffer <= 0) error("AudioRecord no entregó un buffer válido")
        val bufferSize = max(minBuffer * 2, 6400)
        val localRecorder = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )
        if (localRecorder.state != AudioRecord.STATE_INITIALIZED) {
            localRecorder.release()
            error("No se pudo inicializar AudioRecord")
        }
        recorder = localRecorder
        audioFile.parentFile?.mkdirs()
        val wav = RandomAccessFile(audioFile, "rw")
        wav.setLength(0)
        wav.write(ByteArray(44))
        var pcmBytes = 0L
        var bytesAtLastHeader = 0L
        val headerIntervalBytes = SAMPLE_RATE * 2L * 5L
        val buffer = ByteArray(bufferSize)

        try {
            localRecorder.startRecording()
            if (localRecorder.recordingState != AudioRecord.RECORDSTATE_RECORDING) error("Android no permitió iniciar la captura del micrófono")
            dispatchStatus("Escuchando · Vosk en vivo + audio temporal…")
            while (running) {
                val read = localRecorder.read(buffer, 0, buffer.size)
                if (read > 0) {
                    wav.write(buffer, 0, read)
                    pcmBytes += read
                    if (pcmBytes - bytesAtLastHeader >= headerIntervalBytes) {
                        writeWavHeader(wav, pcmBytes)
                        wav.seek(44L + pcmBytes)
                        bytesAtLastHeader = pcmBytes
                    }
                    val rec = recognizer ?: break
                    if (rec.acceptWaveForm(buffer, read)) emitFinal(rec.result)
                    else dispatchPartial(textFromJson(rec.partialResult, "partial"))
                } else if (read < 0 && running) error("Error AudioRecord: $read")
            }
            recognizer?.let { emitFinal(it.finalResult) }
        } finally {
            try { localRecorder.stop() } catch (_: Exception) {}
            localRecorder.release()
            recorder = null
            writeWavHeader(wav, pcmBytes)
            wav.close()
            dispatchPartial("")
        }
    }

    fun stop(): File? {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { captureFuture?.get(3, TimeUnit.SECONDS) } catch (_: Exception) {}
        captureFuture = null
        return audioFile.takeIf { it.isFile && it.length() > 44 }
    }

    fun dispose() {
        stop()
        cleanupNative()
        executor.shutdownNow()
    }

    private fun cleanupNative() {
        try { recognizer?.close() } catch (_: Exception) {}
        recognizer = null
        try { model?.close() } catch (_: Exception) {}
        model = null
    }

    private fun emitFinal(json: String?) {
        val raw = textFromJson(json, "text")
        val text = TranscriptPostProcessor.refine(raw, participants, glossary)
        dispatchPartial("")
        if (text.isBlank()) return
        val normalized = text.lowercase().replace(Regex("\\s+"), " ").trim()
        val previous = lastFinal.lowercase().replace(Regex("\\s+"), " ").trim()
        if (normalized != previous) {
            lastFinal = text
            mainHandler.post { onFinalText(text) }
        }
    }

    private fun dispatchPartial(value: String) = mainHandler.post { onPartialText(value) }
    private fun dispatchStatus(value: String) = mainHandler.post { onStatus(value) }
    private fun dispatchFatal(value: String) { running = false; mainHandler.post { onFatalError(value) } }

    private fun textFromJson(json: String?, field: String): String {
        if (json.isNullOrBlank()) return ""
        return try { JSONObject(json).optString(field).trim() } catch (_: Exception) { "" }
    }

    private fun ensureModelExtracted(): File {
        val base = File(appContext.filesDir, "models/vosk").apply { mkdirs() }
        val modelDir = File(base, MODEL_DIR)
        val readyMarker = File(modelDir, ".ready")
        val conf = File(modelDir, "conf/model.conf")
        if (readyMarker.isFile && conf.isFile) return modelDir

        dispatchStatus("Preparando Vosk español por primera vez…")
        if (modelDir.exists()) modelDir.deleteRecursively()
        appContext.assets.open(MODEL_ASSET).use { input ->
            ZipInputStream(input.buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    val safeName = entry.name.replace('\\', '/')
                    if (safeName.contains("../")) error("Modelo Vosk inválido")
                    val out = File(base, safeName)
                    if (!out.canonicalPath.startsWith(base.canonicalPath + File.separator)) error("Ruta de modelo Vosk inválida")
                    if (entry.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { output -> zip.copyTo(output, 256 * 1024) }
                    }
                    zip.closeEntry()
                }
            }
        }
        if (!conf.isFile) error("El modelo Vosk incluido está incompleto")
        readyMarker.writeText("ok")
        return modelDir
    }

    private fun writeWavHeader(file: RandomAccessFile, pcmBytes: Long) {
        val channels = 1
        val bits = 16
        val byteRate = SAMPLE_RATE * channels * bits / 8
        file.seek(0)
        file.writeBytes("RIFF")
        writeLeInt(file, (36L + pcmBytes).coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
        file.writeBytes("WAVE")
        file.writeBytes("fmt ")
        writeLeInt(file, 16)
        writeLeShort(file, 1)
        writeLeShort(file, channels)
        writeLeInt(file, SAMPLE_RATE)
        writeLeInt(file, byteRate)
        writeLeShort(file, channels * bits / 8)
        writeLeShort(file, bits)
        file.writeBytes("data")
        writeLeInt(file, pcmBytes.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
    }

    private fun writeLeInt(file: RandomAccessFile, value: Int) {
        file.write(value and 0xff); file.write((value ushr 8) and 0xff); file.write((value ushr 16) and 0xff); file.write((value ushr 24) and 0xff)
    }
    private fun writeLeShort(file: RandomAccessFile, value: Int) {
        file.write(value and 0xff); file.write((value ushr 8) and 0xff)
    }
}
