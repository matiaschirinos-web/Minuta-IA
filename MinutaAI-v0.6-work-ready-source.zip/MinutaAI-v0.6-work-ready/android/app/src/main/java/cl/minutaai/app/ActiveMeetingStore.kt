package cl.minutaai.app

import android.content.Context
import com.google.gson.Gson
import java.io.File
import java.io.RandomAccessFile
import java.util.UUID

class ActiveMeetingStore(context: Context) {
    private val appContext = context.applicationContext
    private val gson = Gson()
    private val stateFile = File(appContext.filesDir, "active_meeting.json")
    private val prefs = appContext.getSharedPreferences("active_meeting_meta", Context.MODE_PRIVATE)

    @Synchronized fun read(): ActiveMeetingState {
        if (!stateFile.exists()) return ActiveMeetingState()
        return try { gson.fromJson(stateFile.readText(), ActiveMeetingState::class.java) ?: ActiveMeetingState() } catch (_: Exception) { ActiveMeetingState() }
    }
    @Synchronized fun write(state: ActiveMeetingState) {
        val tmp = File(stateFile.parentFile, "${stateFile.name}.tmp"); tmp.writeText(gson.toJson(state))
        if (!tmp.renameTo(stateFile)) { stateFile.writeText(gson.toJson(state)); tmp.delete() }
    }
    @Synchronized fun clear() { stateFile.delete() }

    @Synchronized fun recoverIfStale(staleAfterMs: Long = 60_000L): String? {
        val state = read(); if (!state.active || state.heartbeatAt <= 0L) return null
        if (System.currentTimeMillis() - state.heartbeatAt <= staleAfterMs) return null
        val text = state.transcript.trim()
        val audio = state.audioPath.takeIf { it.isNotBlank() }?.let { File(it) }
        if (audio != null && audio.isFile && audio.length() > 44) repairWavHeader(audio)
        if (text.isBlank() && (audio == null || !audio.isFile || audio.length() <= 44)) { clear(); return null }
        val id = state.id.ifBlank { UUID.randomUUID().toString() }
        val meeting = Meeting(
            id = id,
            title = state.title.ifBlank { "Reunión recuperada" },
            createdAt = state.startedAt.takeIf { it > 0L } ?: state.heartbeatAt,
            durationMs = (state.heartbeatAt - state.startedAt).coerceAtLeast(0L),
            template = state.template,
            participants = state.participants,
            glossary = state.glossary,
            audioPath = audio?.takeIf { it.isFile && it.length() > 44 }?.absolutePath.orEmpty(),
            transcript = text,
            liveTranscript = text,
            transcriptEngine = if (audio?.isFile == true) "Vosk recuperado · audio disponible para reprocesar con Whisper" else "Vosk (recuperación tras interrupción)",
            transcriptReviewedAt = 0L,
            minutes = "",
            minuteEngine = "Pendiente de revisión"
        )
        MeetingRepository(appContext).save(meeting); setLastSavedMeetingId(id); clear(); return id
    }

    private fun repairWavHeader(file: File) {
        try {
            val pcmBytes = (file.length() - 44L).coerceAtLeast(0L)
            RandomAccessFile(file, "rw").use { wav ->
                wav.seek(0); wav.writeBytes("RIFF"); writeLeInt(wav, (36L + pcmBytes).coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
                wav.writeBytes("WAVE"); wav.writeBytes("fmt "); writeLeInt(wav, 16); writeLeShort(wav, 1); writeLeShort(wav, 1)
                writeLeInt(wav, 16000); writeLeInt(wav, 32000); writeLeShort(wav, 2); writeLeShort(wav, 16)
                wav.writeBytes("data"); writeLeInt(wav, pcmBytes.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
            }
        } catch (_: Exception) {}
    }
    private fun writeLeInt(file: RandomAccessFile, value: Int) { file.write(value and 0xff); file.write((value ushr 8) and 0xff); file.write((value ushr 16) and 0xff); file.write((value ushr 24) and 0xff) }
    private fun writeLeShort(file: RandomAccessFile, value: Int) { file.write(value and 0xff); file.write((value ushr 8) and 0xff) }

    fun setLastSavedMeetingId(id: String) { prefs.edit().putString("last_saved_meeting_id", id).apply() }
    fun lastSavedMeetingId(): String = prefs.getString("last_saved_meeting_id", "").orEmpty()
    fun setLastError(message: String) { prefs.edit().putString("last_error", message).apply() }
    fun lastError(): String = prefs.getString("last_error", "").orEmpty()
    fun clearLastError() { prefs.edit().remove("last_error").apply() }
}
