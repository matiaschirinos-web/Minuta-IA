package cl.minutaai.app

import android.content.Context
import dev.ffmpegkit.whisper.Whisper
import dev.ffmpegkit.whisper.WhisperConfig
import java.io.File

class WhisperTranscriber(private val context: Context) {
    companion object { const val MODEL_ASSET = "models/ggml-small-q5_1.bin" }
    data class Result(val text: String, val engine: String, val processingMs: Long)

    suspend fun transcribe(audioFile: File, participants: String, glossary: String): Result {
        require(audioFile.isFile && audioFile.length() > 44) { "El audio temporal está vacío" }
        val model = Whisper.loadModelFromAsset(context, MODEL_ASSET)
        return try {
            val result = Whisper.transcribe(
                model,
                audioFile.absolutePath,
                WhisperConfig(language = "es", translate = false, threads = 6, printTimestamps = true)
            )
            val timestamped = result.segments.mapNotNull { segment ->
                val refined = TranscriptPostProcessor.refine(segment.text, participants, glossary).trim()
                if (refined.isBlank()) null else "[${formatTimestamp(segment.startMs)}] $refined"
            }.joinToString("
")
            val fallback = TranscriptPostProcessor.refine(result.text, participants, glossary)
            Result(
                text = timestamped.ifBlank { fallback },
                engine = "Whisper Small q5_1 + timestamps + glosario",
                processingMs = result.processingTimeMs
            )
        } finally {
            Whisper.releaseModel(model)
        }
    }

    private fun formatTimestamp(ms: Long): String {
        val total = (ms / 1000).coerceAtLeast(0)
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) "%02d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    }
}
