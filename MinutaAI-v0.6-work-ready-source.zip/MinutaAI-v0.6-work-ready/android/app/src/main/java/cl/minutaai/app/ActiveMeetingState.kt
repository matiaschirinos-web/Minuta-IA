package cl.minutaai.app

data class ActiveMeetingState(
    val active: Boolean = false,
    val id: String = "",
    val title: String = "",
    val template: String = "General",
    val participants: String = "",
    val glossary: String = "",
    val audioPath: String = "",
    val startedAt: Long = 0L,
    val heartbeatAt: Long = 0L,
    val transcript: String = "",
    val partial: String = "",
    val status: String = "Detenido"
)
