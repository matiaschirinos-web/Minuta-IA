package cl.minutaai.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordingActivity : AppCompatActivity() {
    private lateinit var activeStore: ActiveMeetingStore
    private lateinit var knowledgeStore: KnowledgeStore
    private lateinit var titleInput: EditText
    private lateinit var participantsInput: EditText
    private lateinit var glossaryInput: EditText
    private lateinit var templateSpinner: Spinner
    private lateinit var recordButton: Button
    private lateinit var cancelButton: Button
    private lateinit var statusText: TextView
    private lateinit var timerText: TextView
    private lateinit var transcriptPreview: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var requestedStop = false
    private var startingService = false
    private var savedIdBeforeStop = ""

    private val uiTicker = object : Runnable { override fun run() { renderServiceState(); handler.postDelayed(this, 500) } }
    private val audioPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) ensureNotificationPermissionThenStart() else Toast.makeText(this, "Necesito permiso de micrófono.", Toast.LENGTH_LONG).show() }
    private val notificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { startBackgroundMeeting() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_recording)
        activeStore = ActiveMeetingStore(this)
        knowledgeStore = KnowledgeStore(this)
        titleInput = findViewById(R.id.titleInput); participantsInput = findViewById(R.id.participantsInput); glossaryInput = findViewById(R.id.glossaryInput)
        templateSpinner = findViewById(R.id.templateSpinner); recordButton = findViewById(R.id.recordButton); cancelButton = findViewById(R.id.cancelButton)
        statusText = findViewById(R.id.statusText); timerText = findViewById(R.id.timerText); transcriptPreview = findViewById(R.id.transcriptPreview)
        templateSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("General", "Proyecto", "Técnica", "Cliente"))
        titleInput.setText("Reunión ${SimpleDateFormat("dd-MM HH:mm", Locale.getDefault()).format(Date())}")
        participantsInput.setText(knowledgeStore.recentParticipants())
        glossaryInput.setText(knowledgeStore.globalGlossary())
        recordButton.setOnClickListener { if (activeStore.read().active) requestStopAndSave() else ensurePermissionsAndStart() }
        cancelButton.setOnClickListener {
            if (activeStore.read().active) startService(Intent(this, MeetingCaptureService::class.java).apply { action = MeetingCaptureService.ACTION_CANCEL })
            finish()
        }
    }

    override fun onResume() { super.onResume(); activeStore.recoverIfStale(); handler.removeCallbacks(uiTicker); handler.post(uiTicker) }
    override fun onPause() { handler.removeCallbacks(uiTicker); super.onPause() }

    private fun ensurePermissionsAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) ensureNotificationPermissionThenStart()
        else audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
    private fun ensureNotificationPermissionThenStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else startBackgroundMeeting()
    }
    private fun startBackgroundMeeting() {
        if (activeStore.read().active || startingService) return
        knowledgeStore.remember(participantsInput.text.toString(), glossaryInput.text.toString())
        startingService = true; requestedStop = false
        val intent = Intent(this, MeetingCaptureService::class.java).apply {
            action = MeetingCaptureService.ACTION_START
            putExtra(MeetingCaptureService.EXTRA_TITLE, titleInput.text.toString())
            putExtra(MeetingCaptureService.EXTRA_TEMPLATE, templateSpinner.selectedItem?.toString() ?: "General")
            putExtra(MeetingCaptureService.EXTRA_PARTICIPANTS, participantsInput.text.toString())
            putExtra(MeetingCaptureService.EXTRA_GLOSSARY, glossaryInput.text.toString())
        }
        try {
            ContextCompat.startForegroundService(this, intent)
            statusText.text = "Iniciando captura local…"; recordButton.isEnabled = false
            handler.postDelayed({ startingService = false; renderServiceState() }, 900)
        } catch (e: Exception) {
            startingService = false; recordButton.isEnabled = true
            Toast.makeText(this, "No se pudo iniciar: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
    private fun requestStopAndSave() {
        requestedStop = true; savedIdBeforeStop = activeStore.lastSavedMeetingId(); recordButton.isEnabled = false
        statusText.text = "Finalizando; Whisper de alta precisión procesará la reunión…"
        startService(Intent(this, MeetingCaptureService::class.java).apply { action = MeetingCaptureService.ACTION_STOP })
    }
    private fun renderServiceState() {
        val state = activeStore.read()
        if (state.active) {
            startingService = false
            titleInput.setTextIfChanged(state.title); participantsInput.setTextIfChanged(state.participants); glossaryInput.setTextIfChanged(state.glossary); selectTemplate(state.template)
            listOf(titleInput, participantsInput, glossaryInput).forEach { it.isEnabled = false }; templateSpinner.isEnabled = false
            val processing = state.status.contains("Whisper", true) || state.status.contains("minuta", true) || state.status.contains("Cerrando", true) || state.status.contains("Guardando", true)
            recordButton.isEnabled = !processing; recordButton.text = if (processing) "Procesando en el teléfono…" else "Finalizar y mejorar"
            cancelButton.text = "Cancelar reunión"; timerText.text = formatDuration(System.currentTimeMillis() - state.startedAt)
            statusText.text = "Segundo plano activo · ${state.status}\nPuedes bloquear la pantalla o cambiar de app."
            transcriptPreview.text = when {
                state.transcript.isBlank() && state.partial.isBlank() -> "La transcripción en vivo aparecerá aquí."
                state.partial.isBlank() -> state.transcript
                state.transcript.isBlank() -> "…${state.partial}"
                else -> "${state.transcript}\n…${state.partial}"
            }
            return
        }
        if (startingService) return
        listOf(titleInput, participantsInput, glossaryInput).forEach { it.isEnabled = true }; templateSpinner.isEnabled = true
        recordButton.isEnabled = true; recordButton.text = "Iniciar reunión en segundo plano"; cancelButton.text = "Volver"; timerText.text = "00:00"
        if (requestedStop) {
            val savedId = activeStore.lastSavedMeetingId(); requestedStop = false
            if (savedId.isNotBlank() && savedId != savedIdBeforeStop) {
                startActivity(Intent(this, MeetingDetailActivity::class.java).apply { putExtra("meeting_id", savedId) }); finish(); return
            }
            statusText.text = "La reunión terminó, pero no se pudo guardar una transcripción útil."
        } else {
            val error = activeStore.lastError()
            statusText.text = if (error.isNotBlank()) "Último error: $error" else "Vosk en vivo + Whisper Small al finalizar · revisa el texto antes de generar la minuta"
        }
    }
    private fun EditText.setTextIfChanged(value: String) { if (text.toString() != value) setText(value) }
    private fun selectTemplate(value: String) { val adapter = templateSpinner.adapter ?: return; for (i in 0 until adapter.count) if (adapter.getItem(i)?.toString() == value) { if (templateSpinner.selectedItemPosition != i) templateSpinner.setSelection(i); return } }
    private fun formatDuration(ms: Long): String { val total = (ms / 1000).coerceAtLeast(0); return "%02d:%02d".format(total / 60, total % 60) }
}
