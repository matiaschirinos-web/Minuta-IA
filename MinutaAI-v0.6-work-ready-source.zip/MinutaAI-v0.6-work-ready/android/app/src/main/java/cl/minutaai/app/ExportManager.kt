package cl.minutaai.app

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ExportManager {
    fun exportTxt(context: Context, meeting: Meeting): File = createExportFile(context, meeting, "txt").also { it.writeText(renderPlain(meeting)) }

    fun exportPdf(context: Context, meeting: Meeting): File {
        val file = createExportFile(context, meeting, "pdf")
        val doc = PdfDocument(); val paint = Paint().apply { textSize = 11f }; val titlePaint = Paint().apply { textSize = 16f; isFakeBoldText = true }
        val width = 595; val height = 842; val margin = 40f; val lineHeight = 16f; var pageNo = 1; var page = doc.startPage(PdfDocument.PageInfo.Builder(width, height, pageNo).create()); var canvas = page.canvas; var y = margin
        fun newPage() { doc.finishPage(page); pageNo++; page = doc.startPage(PdfDocument.PageInfo.Builder(width, height, pageNo).create()); canvas = page.canvas; y = margin }
        canvas.drawText(meeting.title.take(70), margin, y, titlePaint); y += 26f
        wrapLines(renderPlain(meeting), 88).forEach { line -> if (y > height - margin) newPage(); canvas.drawText(line, margin, y, paint); y += lineHeight }
        doc.finishPage(page); FileOutputStream(file).use { doc.writeTo(it) }; doc.close(); return file
    }

    fun exportDocx(context: Context, meeting: Meeting): File {
        val file = createExportFile(context, meeting, "docx")
        ZipOutputStream(FileOutputStream(file)).use { zip ->
            put(zip, "[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>""")
            put(zip, "_rels/.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>""")
            val paragraphs = renderPlain(meeting).lines().joinToString("") { line -> "<w:p><w:r><w:t xml:space="preserve">${xml(line)}</w:t></w:r></w:p>" }
            put(zip, "word/document.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>$paragraphs<w:sectPr/></w:body></w:document>""")
        }
        return file
    }

    fun uri(context: Context, file: File) = FileProvider.getUriForFile(context, "${context.packageName}.files", file)

    private fun renderPlain(meeting: Meeting): String = buildString {
        appendLine(meeting.title); appendLine("Tipo: ${meeting.template}"); appendLine("Participantes: ${meeting.participants.ifBlank { "No informados" }}"); appendLine(); appendLine(meeting.minutes.ifBlank { "Minuta aún no generada." })
    }
    private fun createExportFile(context: Context, meeting: Meeting, ext: String): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }; val safe = meeting.title.replace(Regex("[^A-Za-z0-9ÁÉÍÓÚáéíóúÑñ _-]"), "").trim().replace(' ', '_').take(50).ifBlank { "minuta" }; return File(dir, "$safe.$ext")
    }
    private fun put(zip: ZipOutputStream, path: String, text: String) { zip.putNextEntry(ZipEntry(path)); zip.write(text.toByteArray(Charsets.UTF_8)); zip.closeEntry() }
    private fun xml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace(""", "&quot;")
    private fun wrapLines(text: String, max: Int): List<String> { val out=mutableListOf<String>(); text.lines().forEach { raw -> if(raw.isBlank()) { out += ""; return@forEach }; var line=""; raw.split(Regex("""\s+""")).forEach { w -> val next=if(line.isBlank()) w else "$line $w"; if(next.length>max && line.isNotBlank()) { out+=line; line=w } else line=next }; if(line.isNotBlank()) out+=line }; return out }
}
