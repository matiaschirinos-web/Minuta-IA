package cl.minutaai.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

class MeetingCaptureService : Service() {
    companion object {
        const val ACTION_START = "cl.minutaai.app.action.START_MEETING"
        const val ACTION_STOP = "cl.minutaai.app.action.STOP_MEETING"
        const val ACTION_CANCEL = "cl.minutaai.app.action.CANCEL_MEETING"
        const val EXTRA_TITLE = "title"
        const val EXTRA_TEMPLATE = "template"
        const val EXTRA_PARTICIPANTS = "participants"
        const val EXTRA_GLOSSARY = "glossary"
        const val CHANNEL_ID = "meeting_capture"
        const val NOTIFICATION_ID = 4101
    }

    private lateinit var activeStore: ActiveMeetingStore
    private lateinit var repo: MeetingRepository
    private var speech: VoskSpeechController? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var state = ActiveMeetingState()
    private var stopping = false

    private val notificationTick = object : Runnable {
        override fun run() {
            if (!state.active) return
            state = state.copy(heartbeatAt = System.currentTimeMillis())
            activeStore.write(state)
            updateNotification()
            handler.postDelayed(this, 5_000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        activeStore = ActiveMeetingStore(this)
        repo = MeetingRepository(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startMeeting(
                intent.getStringExtra(EXTRA_TITLE).orEmpty(),
                intent.getStringExtra(EXTRA_TEMPLATE).orEmpty(),
                intent.getStringExtra(EXTRA_PARTICIPANTS).orEmpty(),
                intent.getStringExtra(EXTRA_GLOSSARY).orEmpty()
            )
            ACTION_STOP -> finishMeeting(true)
            ACTION_CANCEL -> finishMeeting(false)
        }
        return START_NOT_STICKY
    }

    private fun startMeeting(rawTitle: String, rawTemplate: String, participants: String, glossary: String) {
        if (state.active) { updateNotification(); return }
        val id = UUID.randomUUID().toString()
        val audio = File(filesDir, "audio/$id.wav")
        state = ActiveMeetingState(
            active = true,
            id = id,
            title = rawTitle.trim().ifBlank { "Reunión" },
            template = rawTemplate.ifBlank { "General" },
            participants = participants.trim(),
            glossary = glossary.trim(),
            audioPath = audio.absolutePath,
            startedAt = System.currentTimeMillis(),
            heartbeatAt = System.currentTimeMillis(),
            status = "Iniciando captura local…"
        )
        activeStore.write(state)
        startAsMicrophoneForegroundService(buildNotification())
        acquireWakeLock()
        handler.removeCallbacks(notificationTick)
        handler.post(notificationTick)
        activeStore.clearLastError()

        speech = VoskSpeechController(
            context = this,
            audioFile = audio,
            participants = state.participants,
            glossary = state.glossary,
            onFinalText = { appendFinalText(it) },
            onPartialText = { state = state.copy(partial = it); activeStore.write(state) },
            onStatus = { state = state.copy(status = it); activeStore.write(state); updateNotification() },
            onFatalError = { message ->
                state = state.copy(status = message); activeStore.write(state); activeStore.setLastError(message)
                finishMeeting(state.transcript.isNotBlank())
            }
        )
        if (speech?.start() != true) finishMeeting(false)
    }

    private fun appendFinalText(text: String) {
        val clean = text.trim()
        if (clean.isBlank() || !state.active) return
        state = state.copy(transcript = if (state.transcript.isBlank()) clean else "${state.transcript}\n$clean", partial = "")
        activeStore.write(state)
    }

    private fun finishMeeting(save: Boolean) {
        if (stopping || (!state.active && speech == null)) return
        stopping = true
        val partial = state.partial.trim()
        if (partial.isNotBlank() && !state.transcript.trim().endsWith(partial, true)) {
            state = state.copy(transcript = if (state.transcript.isBlank()) partial else "${state.transcript}\n$partial", partial = "")
        }
        state = state.copy(status = if (save) "Cerrando audio…" else "Cancelando reunión…")
        activeStore.write(state); updateNotification()

        val audioFile = speech?.stop()
        speech = null
        if (!save) {
            audioFile?.delete(); completeStop(); return
        }
        state = state.copy(status = "Mejorando transcripción con Whisper…")
        activeStore.write(state); updateNotification()
        scope.launch { finalizeWithWhisper(audioFile) }
    }

private suspend fun finalizeWithWhisper(audioFile: File?) {
    val endedAt = System.currentTimeMillis()
    val voskText = state.transcript.trim()
    var finalText = voskText
    var engine = "Vosk en vivo"
    var whisperError = ""

    if (audioFile != null && audioFile.isFile) {
        try {
            val result = WhisperTranscriber(applicationContext).transcribe(audioFile, state.participants, state.glossary)
            if (result.text.isNotBlank()) {
                finalText = result.text
                engine = "${result.engine} (${result.processingMs / 1000}s de proceso)"
            }
        } catch (e: Exception) {
            whisperError = e.message ?: e.javaClass.simpleName
        }
    }
    finalText = TranscriptPostProcessor.refine(finalText, state.participants, state.glossary)
    if (finalText.isBlank()) {
        handler.post {
            activeStore.setLastError("No se obtuvo texto útil${if (whisperError.isNotBlank()) ": $whisperError" else ""}.")
            audioFile?.delete(); completeStop()
        }
        return
    }

    handler.post {
        state = state.copy(status = "Guardando transcripción para revisión…", transcript = finalText, partial = "")
        activeStore.write(state); updateNotification()
    }

    val keepAudio = OfflineModelSettings.keepAudio(applicationContext)
    val meeting = Meeting(
        id = state.id.ifBlank { UUID.randomUUID().toString() },
        title = state.title.ifBlank { "Reunión" },
        createdAt = state.startedAt.takeIf { it > 0 } ?: endedAt,
        durationMs = (endedAt - state.startedAt).coerceAtLeast(0),
        template = state.template,
        participants = state.participants,
        glossary = state.glossary,
        audioPath = if (keepAudio) audioFile?.absolutePath.orEmpty() else "",
        transcript = finalText,
        liveTranscript = voskText,
        transcriptEngine = if (whisperError.isBlank()) engine else "$engine · Whisper falló: $whisperError",
        transcriptReviewedAt = 0L,
        minutes = "",
        minuteEngine = "Pendiente de revisión de transcripción"
    )
    repo.save(meeting)
    activeStore.setLastSavedMeetingId(meeting.id)
    if (!keepAudio) audioFile?.delete()
    handler.post { completeStop() }
}

    private fun completeStop() {
        handler.removeCallbacks(notificationTick)
        state = ActiveMeetingState()
        activeStore.clear()
        releaseWakeLock()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
        stopping = false
    }

    private fun startAsMicrophoneForegroundService(notification: Notification) {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    private fun buildNotification(): Notification {
        val openPending = PendingIntent.getActivity(
            this, 1,
            Intent(this, RecordingActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopPending = PendingIntent.getService(
            this, 2,
            Intent(this, MeetingCaptureService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val elapsed = if (state.startedAt > 0) formatDuration(System.currentTimeMillis() - state.startedAt) else "00:00"
        val preview = when {
            state.status.contains("Whisper", true) || state.status.contains("minuta", true) -> state.status
            state.transcript.isNotBlank() -> state.transcript.lineSequence().lastOrNull()?.take(90).orEmpty()
            else -> state.status
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Minuta IA · $elapsed")
            .setContentText(preview)
            .setStyle(NotificationCompat.BigTextStyle().bigText(preview))
            .setContentIntent(openPending)
            .setOngoing(true).setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE).setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(android.R.drawable.ic_media_pause, "Finalizar", stopPending)
            .build()
    }

    private fun updateNotification() { getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification()) }
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Reunión en segundo plano", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Captura local y procesamiento offline de reuniones."; setSound(null, null)
            }
        )
    }
    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        wakeLock = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MinutaAI::MeetingCapture").apply {
            setReferenceCounted(false); acquire()
        }
    }
    private fun releaseWakeLock() { try { wakeLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) {}; wakeLock = null }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); speech?.dispose(); speech = null; scope.cancel(); releaseWakeLock(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
    private fun formatDuration(ms: Long): String { val total = (ms / 1000).coerceAtLeast(0); return "%02d:%02d".format(total / 60, total % 60) }
}
