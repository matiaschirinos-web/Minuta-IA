package cl.minutaai.app

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

class MeetingRepository(private val context: Context) {
    private val gson = Gson()
    private val dataFile = File(context.filesDir, "meetings.json")

    @Synchronized
    fun list(): MutableList<Meeting> {
        if (!dataFile.exists()) return mutableListOf()
        return try {
            val type = object : TypeToken<MutableList<Meeting>>() {}.type
            gson.fromJson(dataFile.readText(), type) ?: mutableListOf()
        } catch (_: Exception) {
            mutableListOf()
        }
    }

    @Synchronized
    fun get(id: String): Meeting? = list().firstOrNull { it.id == id }

    @Synchronized
    fun save(meeting: Meeting) {
        val items = list()
        val index = items.indexOfFirst { it.id == meeting.id }
        if (index >= 0) items[index] = meeting else items.add(meeting)
        dataFile.writeText(gson.toJson(items))
    }
}
