package cl.minutaai.app

data class Meeting(
    val id: String,
    var title: String,
    val createdAt: Long,
    val durationMs: Long,
    val template: String,
    var participants: String = "",
    var glossary: String = "",
    var audioPath: String = "",
    var transcript: String = "",
    var liveTranscript: String = "",
    var transcriptEngine: String = "",
    var transcriptReviewedAt: Long = 0L,
    var minutes: String = "",
    var minuteEngine: String = ""
)
