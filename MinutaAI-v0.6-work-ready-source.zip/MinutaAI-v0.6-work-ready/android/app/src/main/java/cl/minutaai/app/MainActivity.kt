package cl.minutaai.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.DateFormat
import java.util.Date

class MainActivity : AppCompatActivity() {
    private lateinit var repo: MeetingRepository
    private lateinit var listContainer: LinearLayout
    private lateinit var newMeetingButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        repo = MeetingRepository(this)
        listContainer = findViewById(R.id.meetingList)

        newMeetingButton = findViewById(R.id.newMeetingButton)
        newMeetingButton.setOnClickListener {
            startActivity(Intent(this, RecordingActivity::class.java))
        }
        findViewById<Button>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        val activeStore = ActiveMeetingStore(this)
        activeStore.recoverIfStale()
        val active = activeStore.read().active
        newMeetingButton.text = if (active) "Volver a reunión en curso" else "Nueva reunión"
        renderMeetings()
    }

    private fun renderMeetings() {
        listContainer.removeAllViews()
        val meetings = repo.list().sortedByDescending { it.createdAt }
        if (meetings.isEmpty()) {
            val empty = TextView(this).apply {
                text = "Todavía no hay reuniones."
                textSize = 16f
                setPadding(0, 24, 0, 0)
            }
            listContainer.addView(empty)
            return
        }

        meetings.forEach { meeting ->
            val button = Button(this).apply {
                val whenText = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                    .format(Date(meeting.createdAt))
                text = "${meeting.title}\n$whenText · ${formatDuration(meeting.durationMs)}"
                textAlignment = View.TEXT_ALIGNMENT_TEXT_START
                isAllCaps = false
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, MeetingDetailActivity::class.java).apply {
                        putExtra("meeting_id", meeting.id)
                    })
                }
            }
            listContainer.addView(button)
        }
    }

    private fun formatDuration(ms: Long): String {
        val total = ms / 1000
        return "%02d:%02d".format(total / 60, total % 60)
    }
}
