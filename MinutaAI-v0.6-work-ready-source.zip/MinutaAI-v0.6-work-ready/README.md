# Minuta AI V0.6 — Trabajo

Versión enfocada en reuniones laborales y control de calidad.

## Cambios principales
- Vosk solo como transcripción en vivo.
- Whisper Small q5_1 offline como transcripción final de mayor precisión.
- Timestamps por segmento para volver al punto exacto de la conversación.
- La minuta NO se genera automáticamente: primero se revisa/corrige la transcripción.
- Glosario laboral persistente y participantes recientes.
- Minuta profesional editable con decisiones, tareas, propuestas, pendientes, riesgos y niveles de confianza.
- Exportación local a TXT/compartir, DOCX y PDF.
- WAV con cabecera actualizada cada 5 segundos para mejorar recuperación tras cierres inesperados.
- Si una reunión se interrumpe y queda audio recuperable, puede reprocesarse con Whisper desde el detalle.
- Sin permiso INTERNET en la app. Los modelos se incorporan durante GitHub Actions.

## Privacidad
El audio se elimina después de transcribir salvo que el usuario active Conservar audio. En una recuperación tras cierre inesperado, el audio se conserva hasta poder reprocesarlo.
