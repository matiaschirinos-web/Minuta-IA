package cl.minutaai.app

import android.content.Context
import com.google.gson.Gson
import java.io.File
import java.util.UUID

class ActiveMeetingStore(context: Context) {
    private val appContext = context.applicationContext
    private val gson = Gson()
    private val stateFile = File(appContext.filesDir, "active_meeting.json")
    private val prefs = appContext.getSharedPreferences("active_meeting_meta", Context.MODE_PRIVATE)

    @Synchronized
    fun read(): ActiveMeetingState {
        if (!stateFile.exists()) return ActiveMeetingState()
        return try {
            gson.fromJson(stateFile.readText(), ActiveMeetingState::class.java) ?: ActiveMeetingState()
        } catch (_: Exception) {
            ActiveMeetingState()
        }
    }

    @Synchronized
    fun write(state: ActiveMeetingState) {
        val tmp = File(stateFile.parentFile, "${stateFile.name}.tmp")
        tmp.writeText(gson.toJson(state))
        if (!tmp.renameTo(stateFile)) {
            stateFile.writeText(gson.toJson(state))
            tmp.delete()
        }
    }

    @Synchronized
    fun clear() {
        stateFile.delete()
    }

    /**
     * Si Android llegó a matar el proceso de forma anormal, evita dejar la UI bloqueada
     * eternamente en "reunión activa" y rescata todo texto confirmado que alcanzó a guardarse.
     */
    @Synchronized
    fun recoverIfStale(staleAfterMs: Long = 60_000L): String? {
        val state = read()
        if (!state.active || state.heartbeatAt <= 0L) return null
        val now = System.currentTimeMillis()
        if (now - state.heartbeatAt <= staleAfterMs) return null

        val text = state.transcript.trim()
        if (text.isBlank()) {
            clear()
            return null
        }

        val id = state.id.ifBlank { UUID.randomUUID().toString() }
        MeetingRepository(appContext).save(
            Meeting(
                id = id,
                title = state.title.ifBlank { "Reunión recuperada" },
                createdAt = state.startedAt.takeIf { it > 0L } ?: state.heartbeatAt,
                durationMs = (state.heartbeatAt - state.startedAt).coerceAtLeast(0L),
                template = state.template,
                transcript = text
            )
        )
        setLastSavedMeetingId(id)
        clear()
        return id
    }

    fun setLastSavedMeetingId(id: String) {
        prefs.edit().putString("last_saved_meeting_id", id).apply()
    }

    fun lastSavedMeetingId(): String = prefs.getString("last_saved_meeting_id", "").orEmpty()

    fun setLastError(message: String) {
        prefs.edit().putString("last_error", message).apply()
    }

    fun lastError(): String = prefs.getString("last_error", "").orEmpty()

    fun clearLastError() {
        prefs.edit().remove("last_error").apply()
    }
}
