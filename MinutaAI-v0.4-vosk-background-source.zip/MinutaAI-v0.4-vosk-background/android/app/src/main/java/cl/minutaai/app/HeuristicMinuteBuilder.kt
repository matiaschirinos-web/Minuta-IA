package cl.minutaai.app

object HeuristicMinuteBuilder {
    private val decisionHints = listOf("se decidió", "decidimos", "acordamos", "queda acordado", "aprobado", "definimos")
    private val taskHints = listOf("tengo que", "tienes que", "debe", "deberá", "quedó de", "me encargo", "se encargará", "vamos a", "hay que")
    private val uncertainHints = listOf("podríamos", "podriamos", "quizás", "quizas", "tal vez", "sería bueno", "seria bueno", "se podría", "se podria", "podemos evaluar", "podemos revisar")
    private val pendingHints = listOf("pendiente", "falta", "por confirmar", "revisar", "validar", "averiguar", "consultar")
    private val riskHints = listOf("riesgo", "bloqueo", "bloqueado", "retraso", "problema", "impacto", "dependencia")

    fun build(transcript: String, template: String): String {
        val cleaned = transcript.trim()
        if (cleaned.isBlank()) return "No hay transcripción suficiente para generar una minuta."

        val sentences = cleaned
            .split(Regex("(?<=[.!?])\\s+|\\n+|\\s{2,}"))
            .map { it.trim() }
            .filter { it.length >= 12 }

        val uncertain = pick(sentences, uncertainHints)
        val decisions = pick(sentences, decisionHints).filterNot { it in uncertain }
        val tasks = pick(sentences, taskHints).filterNot { it in uncertain || it in decisions }
        val pending = pick(sentences, pendingHints).filterNot { it in uncertain || it in decisions || it in tasks }
        val risks = pick(sentences, riskHints)
        val summary = sentences.take(5).joinToString(" ").take(1200)

        return buildString {
            appendLine("# Minuta — $template")
            appendLine()
            appendLine("## Resumen")
            appendLine(summary.ifBlank { cleaned.take(1200) })
            appendLine()
            appendSection("Decisiones", decisions)
            appendSection("Tareas / compromisos explícitos", tasks)
            appendSection("Compromisos por confirmar", uncertain)
            appendSection("Pendientes", pending)
            appendSection("Riesgos / bloqueos", risks)
            appendLine("## Observación")
            appendLine("Esta minuta fue generada localmente con reglas. Revisa responsables, fechas y compromisos antes de compartirla.")
        }.trim()
    }

    private fun pick(sentences: List<String>, hints: List<String>): List<String> =
        sentences.filter { sentence ->
            val s = sentence.lowercase()
            hints.any { it in s }
        }.distinct().take(10)

    private fun StringBuilder.appendSection(title: String, items: List<String>) {
        appendLine("## $title")
        if (items.isEmpty()) appendLine("- No detectado con suficiente certeza.")
        else items.forEach { appendLine("- ${it.trim()}") }
        appendLine()
    }
}
