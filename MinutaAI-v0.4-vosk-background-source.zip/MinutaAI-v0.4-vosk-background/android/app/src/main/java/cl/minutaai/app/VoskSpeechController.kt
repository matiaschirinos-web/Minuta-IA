package cl.minutaai.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

/**
 * Motor de voz 100% local. No depende de SpeechRecognizer ni de los modelos
 * de reconocimiento instalados por Samsung/Google. Vosk lee el micrófono mediante
 * AudioRecord y funciona dentro del foreground service de la reunión.
 */
class VoskSpeechController(
    context: Context,
    private val onFinalText: (String) -> Unit,
    private val onPartialText: (String) -> Unit,
    private val onStatus: (String) -> Unit,
    private val onFatalError: (String) -> Unit,
) : RecognitionListener {

    companion object {
        const val MODEL_ASSET = "vosk-model-small-es-0.42.zip"
        const val MODEL_DIR = "vosk-model-small-es-0.42"
        private const val SAMPLE_RATE = 16000.0f
    }

    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var running = false
    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var speechService: SpeechService? = null
    private var lastFinal = ""

    fun start(): Boolean {
        if (running) return true
        running = true
        onStatus("Preparando motor de voz offline…")
        executor.execute {
            try {
                val modelDir = ensureModelExtracted()
                if (!running) return@execute

                val localModel = Model(modelDir.absolutePath)
                val localRecognizer = Recognizer(localModel, SAMPLE_RATE)
                val localSpeechService = SpeechService(localRecognizer, SAMPLE_RATE)

                model = localModel
                recognizer = localRecognizer
                speechService = localSpeechService

                mainHandler.post {
                    if (!running) return@post
                    try {
                        val started = localSpeechService.startListening(this)
                        if (!started) {
                            fail("El motor de voz ya estaba ocupado y no pudo abrir el micrófono.")
                        } else {
                            onStatus("Escuchando offline…")
                        }
                    } catch (e: Exception) {
                        fail("No se pudo abrir el micrófono: ${e.message ?: e.javaClass.simpleName}")
                    }
                }
            } catch (e: Exception) {
                mainHandler.post {
                    fail("No se pudo iniciar Vosk: ${e.message ?: e.javaClass.simpleName}")
                }
            }
        }
        return true
    }

    fun stop() {
        running = false
        mainHandler.removeCallbacksAndMessages(null)
        try { speechService?.stop() } catch (_: Exception) {}
        try { speechService?.shutdown() } catch (_: Exception) {}
        speechService = null
        try { recognizer?.close() } catch (_: Exception) {}
        recognizer = null
        try { model?.close() } catch (_: Exception) {}
        model = null
        onPartialText("")
        onStatus("Detenido")
    }

    fun dispose() {
        stop()
        executor.shutdownNow()
    }

    private fun fail(message: String) {
        if (!running) return
        running = false
        onFatalError(message)
    }

    private fun ensureModelExtracted(): File {
        val base = File(appContext.filesDir, "models/vosk").apply { mkdirs() }
        val modelDir = File(base, MODEL_DIR)
        val readyMarker = File(modelDir, ".ready")
        val conf = File(modelDir, "conf/model.conf")
        if (readyMarker.isFile && conf.isFile) return modelDir

        onStatus("Preparando modelo español offline por primera vez…")
        if (modelDir.exists()) modelDir.deleteRecursively()
        base.mkdirs()

        appContext.assets.open(MODEL_ASSET).use { input ->
            ZipInputStream(input.buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    val safeName = entry.name.replace('\\', '/')
                    if (safeName.contains("../")) throw IllegalStateException("Modelo inválido")
                    val out = File(base, safeName)
                    if (!out.canonicalPath.startsWith(base.canonicalPath + File.separator)) {
                        throw IllegalStateException("Ruta de modelo inválida")
                    }
                    if (entry.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { output -> zip.copyTo(output, 256 * 1024) }
                    }
                    zip.closeEntry()
                }
            }
        }

        if (!conf.isFile) throw IllegalStateException("El modelo español incluido está incompleto")
        readyMarker.writeText("ok")
        return modelDir
    }

    private fun textFromJson(json: String?, field: String): String {
        if (json.isNullOrBlank()) return ""
        return try { JSONObject(json).optString(field).trim() } catch (_: Exception) { "" }
    }

    private fun emitFinal(json: String?) {
        val text = textFromJson(json, "text")
        onPartialText("")
        if (text.isBlank()) return
        val normalized = text.lowercase().replace(Regex("\\s+"), " ").trim()
        val previous = lastFinal.lowercase().replace(Regex("\\s+"), " ").trim()
        if (normalized != previous) {
            lastFinal = text
            onFinalText(text)
        }
    }

    override fun onPartialResult(hypothesis: String) {
        if (!running) return
        onPartialText(textFromJson(hypothesis, "partial"))
    }

    override fun onResult(hypothesis: String) {
        if (!running) return
        emitFinal(hypothesis)
        onStatus("Escuchando offline…")
    }

    override fun onFinalResult(hypothesis: String) {
        emitFinal(hypothesis)
    }

    override fun onError(exception: Exception) {
        if (!running) return
        fail("Error del micrófono offline: ${exception.message ?: "desconocido"}")
    }

    override fun onTimeout() {
        if (running) onStatus("Escuchando offline…")
    }
}
