package cl.minutaai.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.UUID

class MeetingCaptureService : Service() {
    companion object {
        const val ACTION_START = "cl.minutaai.app.action.START_MEETING"
        const val ACTION_STOP = "cl.minutaai.app.action.STOP_MEETING"
        const val ACTION_CANCEL = "cl.minutaai.app.action.CANCEL_MEETING"
        const val EXTRA_TITLE = "title"
        const val EXTRA_TEMPLATE = "template"
        const val CHANNEL_ID = "meeting_capture"
        const val NOTIFICATION_ID = 4101
    }

    private lateinit var activeStore: ActiveMeetingStore
    private lateinit var repo: MeetingRepository
    private var speech: VoskSpeechController? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private var state = ActiveMeetingState()
    private var stopping = false

    private val notificationTick = object : Runnable {
        override fun run() {
            if (!state.active) return
            state = state.copy(heartbeatAt = System.currentTimeMillis())
            activeStore.write(state)
            updateNotification()
            handler.postDelayed(this, 5_000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        activeStore = ActiveMeetingStore(this)
        repo = MeetingRepository(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startMeeting(
                intent.getStringExtra(EXTRA_TITLE).orEmpty(),
                intent.getStringExtra(EXTRA_TEMPLATE).orEmpty()
            )
            ACTION_STOP -> finishMeeting(save = true)
            ACTION_CANCEL -> finishMeeting(save = false)
        }
        // Un servicio de micrófono no debe intentar reanudarse solo desde el fondo
        // si Android lo mata: el usuario debe volver a iniciarlo con la Activity visible.
        return START_NOT_STICKY
    }

    private fun startMeeting(rawTitle: String, rawTemplate: String) {
        if (state.active) {
            updateNotification()
            return
        }
        state = ActiveMeetingState(
            active = true,
            id = UUID.randomUUID().toString(),
            title = rawTitle.trim().ifBlank { "Reunión" },
            template = rawTemplate.ifBlank { "General" },
            startedAt = System.currentTimeMillis(),
            heartbeatAt = System.currentTimeMillis(),
            status = "Iniciando reconocimiento local…"
        )
        activeStore.write(state)

        startAsMicrophoneForegroundService(buildNotification())
        acquireWakeLock()
        handler.removeCallbacks(notificationTick)
        handler.post(notificationTick)

        activeStore.clearLastError()
        speech = VoskSpeechController(
            context = this,
            onFinalText = { text -> appendFinalText(text) },
            onPartialText = { text ->
                state = state.copy(partial = text)
                activeStore.write(state)
            },
            onStatus = { status ->
                state = state.copy(status = status)
                activeStore.write(state)
            },
            onFatalError = { message ->
                state = state.copy(status = message)
                activeStore.write(state)
                activeStore.setLastError(message)
                // Conservamos lo ya transcrito en lugar de perder la reunión.
                finishMeeting(save = state.transcript.isNotBlank())
            }
        )

        if (speech?.start() != true) {
            finishMeeting(save = false)
        }
    }

    private fun appendFinalText(text: String) {
        val clean = text.trim()
        if (clean.isBlank() || !state.active) return
        val updated = if (state.transcript.isBlank()) clean else "${state.transcript}\n$clean"
        state = state.copy(transcript = updated, partial = "")
        activeStore.write(state)
    }

    private fun finishMeeting(save: Boolean) {
        if (stopping || (!state.active && speech == null)) return
        stopping = true

        val finalPartial = state.partial.trim()
        if (finalPartial.isNotBlank()) {
            val alreadyPresent = state.transcript.trim().endsWith(finalPartial, ignoreCase = true)
            if (!alreadyPresent) {
                val updated = if (state.transcript.isBlank()) finalPartial else "${state.transcript}\n$finalPartial"
                state = state.copy(transcript = updated, partial = "")
            }
        }

        speech?.stop()
        speech = null
        handler.removeCallbacks(notificationTick)

        val endedAt = System.currentTimeMillis()
        val shouldSave = save && state.transcript.isNotBlank()
        if (shouldSave) {
            val meeting = Meeting(
                id = state.id.ifBlank { UUID.randomUUID().toString() },
                title = state.title.ifBlank { "Reunión" },
                createdAt = state.startedAt.takeIf { it > 0 } ?: endedAt,
                durationMs = (endedAt - state.startedAt).coerceAtLeast(0),
                template = state.template,
                transcript = state.transcript.trim()
            )
            repo.save(meeting)
            activeStore.setLastSavedMeetingId(meeting.id)
        }

        state = ActiveMeetingState()
        activeStore.clear()
        releaseWakeLock()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
        stopping = false
    }

    private fun startAsMicrophoneForegroundService(notification: Notification) {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, RecordingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this, 1, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, MeetingCaptureService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 2, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val elapsed = if (state.startedAt > 0) formatDuration(System.currentTimeMillis() - state.startedAt) else "00:00"
        val preview = state.transcript.lineSequence().lastOrNull()?.take(90)
            ?: "Escuchando y transcribiendo en el dispositivo"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Reunión en curso · $elapsed")
            .setContentText(preview)
            .setStyle(NotificationCompat.BigTextStyle().bigText(preview))
            .setContentIntent(openPending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(android.R.drawable.ic_media_pause, "Finalizar", stopPending)
            .build()
    }

    private fun updateNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Reunión en segundo plano",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Mantiene visible la transcripción mientras Minuta AI usa el micrófono."
            setSound(null, null)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MinutaAI::MeetingCapture").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.takeIf { it.isHeld }?.release()
        } catch (_: Exception) {
        }
        wakeLock = null
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        speech?.dispose()
        speech = null
        releaseWakeLock()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun formatDuration(ms: Long): String {
        val total = (ms / 1000).coerceAtLeast(0)
        return "%02d:%02d".format(total / 60, total % 60)
    }
}
