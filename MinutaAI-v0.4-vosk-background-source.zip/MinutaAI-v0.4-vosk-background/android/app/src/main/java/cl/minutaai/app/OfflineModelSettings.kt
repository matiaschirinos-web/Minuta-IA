package cl.minutaai.app

import android.content.Context
import java.io.File

object OfflineModelSettings {
    private const val PREFS = "minuta_ai_offline_settings"
    private const val KEY_LLM_PATH = "llm_model_path"
    private const val KEY_LANGUAGE = "speech_language"
    const val DEFAULT_LANGUAGE = "es-CL"

    fun llmModelPath(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LLM_PATH, "").orEmpty()

    fun setLlmModelPath(context: Context, path: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_LLM_PATH, path).apply()
    }

    fun speechLanguage(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LANGUAGE, DEFAULT_LANGUAGE) ?: DEFAULT_LANGUAGE

    fun setSpeechLanguage(context: Context, language: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_LANGUAGE, language.trim().ifBlank { DEFAULT_LANGUAGE }).apply()
    }

    fun hasLlmModel(context: Context): Boolean {
        val path = llmModelPath(context)
        return path.isNotBlank() && File(path).isFile && File(path).length() > 0
    }
}
