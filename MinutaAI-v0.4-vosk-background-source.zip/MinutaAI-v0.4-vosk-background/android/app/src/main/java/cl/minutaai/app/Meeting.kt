package cl.minutaai.app

data class Meeting(
    val id: String,
    var title: String,
    val createdAt: Long,
    val durationMs: Long,
    val template: String,
    val audioPath: String = "",
    var transcript: String = "",
    var minutes: String = "",
    var minuteEngine: String = ""
)
