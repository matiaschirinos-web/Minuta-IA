# Minuta AI Offline v0.4

Versión Android orientada a reuniones largas en segundo plano sin API ni conexión a Internet durante el uso.

## Cambio principal de v0.4

La transcripción ya no usa `android.speech.SpeechRecognizer`. Ahora usa **Vosk + AudioRecord** dentro de un foreground service de tipo `microphone`.

Esto evita depender del modelo de voz instalado por Samsung/Google y del comportamiento del reconocedor del sistema, que en algunos equipos se cerraba inmediatamente al iniciar.

- Motor ASR: Vosk Android 0.3.75.
- Modelo: `vosk-model-small-es-0.42` (español, Apache 2.0), incluido en el APK durante el build.
- Micrófono: AudioRecord administrado por Vosk `SpeechService`.
- Sin permiso INTERNET.
- Foreground service con notificación persistente.
- Wake lock parcial durante la reunión.
- Checkpoint local del estado y transcripción.
- Minuta local por reglas; modelo MediaPipe `.task` opcional para resumen generativo.

## Primera ejecución

La primera reunión puede tardar algunos segundos adicionales mientras el modelo español incluido se descomprime al almacenamiento privado de la app. Después queda reutilizado.

## Segundo plano

La reunión debe iniciarse desde una Activity visible. Una vez que el servicio muestra la notificación persistente, puede cambiarse de app o bloquearse la pantalla y el micrófono continúa dentro del foreground service.
