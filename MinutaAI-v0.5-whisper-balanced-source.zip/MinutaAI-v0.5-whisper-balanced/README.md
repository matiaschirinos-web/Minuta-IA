# Minuta AI V0.5 — Equilibrada

- Un único AudioRecord captura WAV PCM 16 kHz mono.
- Vosk transcribe en vivo.
- Whisper Base vuelve a transcribir el WAV completo al finalizar.
- Participantes y glosario corrigen nombres/términos de forma conservadora.
- La minuta final incluye resumen, participantes, decisiones, tareas, propuestas por confirmar, pendientes, riesgos, conclusiones y próximos pasos.
- Modelo MediaPipe `.task` opcional para redacción generativa local; sin él funciona con análisis extractivo.
- Audio temporal eliminado por defecto; opcionalmente se puede conservar.
- Sin permiso INTERNET en la app. Los modelos se descargan durante el build de GitHub Actions.

La V0.5 no hace diarización de hablantes: puede listar participantes declarados y nombres detectados, pero no afirma qué persona dijo cada frase si no está explícito.
