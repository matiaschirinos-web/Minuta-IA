package cl.minutaai.app

import android.content.Context
import dev.ffmpegkit.whisper.Whisper
import dev.ffmpegkit.whisper.WhisperConfig
import java.io.File

class WhisperTranscriber(private val context: Context) {
    companion object { const val MODEL_ASSET = "models/ggml-base.bin" }
    data class Result(val text: String, val engine: String, val processingMs: Long)

    suspend fun transcribe(audioFile: File, participants: String, glossary: String): Result {
        require(audioFile.isFile && audioFile.length() > 44) { "El audio temporal está vacío" }
        val model = Whisper.loadModelFromAsset(context, MODEL_ASSET)
        return try {
            val result = Whisper.transcribe(
                model,
                audioFile.absolutePath,
                WhisperConfig(language = "es", translate = false, threads = 6, printTimestamps = true)
            )
            Result(
                TranscriptPostProcessor.refine(result.text, participants, glossary),
                "Whisper Base + glosario",
                result.processingTimeMs
            )
        } finally {
            Whisper.releaseModel(model)
        }
    }
}
