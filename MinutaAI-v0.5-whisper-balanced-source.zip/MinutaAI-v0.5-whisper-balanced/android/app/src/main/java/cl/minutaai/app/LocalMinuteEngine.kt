package cl.minutaai.app

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

class LocalMinuteEngine(private val context: Context) {
    data class Result(val minutes: String, val engineName: String)

    fun generate(meeting: Meeting): Result {
        if (meeting.transcript.isBlank()) return Result("No hay transcripción para resumir.", "Sin transcripción")
        val modelPath = OfflineModelSettings.llmModelPath(context)
        if (modelPath.isBlank() || !File(modelPath).isFile) {
            return Result(HeuristicMinuteBuilder.build(meeting), "Análisis extractivo local V0.5")
        }
        return try {
            Result(generateWithLlm(modelPath, meeting), "IA local + transcripción Whisper")
        } catch (e: Exception) {
            Result(
                HeuristicMinuteBuilder.build(meeting) + "\n\n> La IA local no pudo ejecutarse (${e.message ?: "error desconocido"}); se usó análisis extractivo.",
                "Análisis extractivo local (fallback)"
            )
        }
    }

    private fun generateWithLlm(modelPath: String, meeting: Meeting): String {
        val options = LlmInference.LlmInferenceOptions.builder().setModelPath(modelPath).setMaxTokens(4096).build()
        LlmInference.createFromOptions(context, options).use { llm ->
            val header = """
                Tipo: ${meeting.template}
                Participantes informados: ${meeting.participants.ifBlank { "No informados" }}
                Glosario/nombres: ${meeting.glossary.ifBlank { "Sin glosario" }}
                Motor de transcripción: ${meeting.transcriptEngine.ifBlank { "Local" }}
            """.trimIndent()
            val chunks = chunkTranscript(meeting.transcript, 6500)
            val notes = chunks.mapIndexed { index, chunk ->
                llm.generateResponse(
                    """
                    Eres un asistente de minutas extremadamente conservador. Extrae SOLO información respaldada por la transcripción.
                    No inventes personas, responsables, fechas, decisiones ni conclusiones. Conserva los nombres del glosario cuando correspondan.
                    Distingue posibilidades ("podríamos", "quizás", "sería bueno") de decisiones confirmadas. Si no sabes quién dijo algo, no atribuyas hablante.

                    $header
                    Fragmento ${index + 1}/${chunks.size}:
                    $chunk

                    Devuelve: temas, hechos, decisiones explícitas, tareas con responsable/fecha solo si son explícitos, pendientes, riesgos y conclusiones explícitas.
                    """.trimIndent()
                )
            }
            var combined = notes.joinToString("\n\n---\n\n")
            while (combined.length > 9000) {
                combined = chunkTranscript(combined, 6500).joinToString("\n\n---\n\n") { llm.generateResponse("Condensa sin inventar y elimina duplicados:\n$it") }
            }
            return llm.generateResponse(
                """
                Redacta una minuta profesional en español usando exclusivamente estas notas.
                $header

                Reglas:
                - No inventes datos ni atribuyas hablantes si no están identificados.
                - Participantes: lista primero los participantes informados.
                - Mantén separados acuerdos confirmados y propuestas/tentativas.
                - Responsable y fecha solo si fueron explícitos; si falta fecha, escribe "Sin fecha definida".
                - Secciones: Resumen ejecutivo, Participantes, Temas tratados, Decisiones, Tareas y responsables, Compromisos por confirmar, Pendientes, Riesgos/Bloqueos, Conclusiones y Próximos pasos.
                - Las conclusiones deben estar respaldadas por la conversación.

                Notas:
                $combined
                """.trimIndent()
            ).trim().ifBlank { HeuristicMinuteBuilder.build(meeting) }
        }
    }

    private fun chunkTranscript(text: String, maxChars: Int): List<String> {
        if (text.length <= maxChars) return listOf(text)
        val chunks = mutableListOf<String>()
        var start = 0
        while (start < text.length) {
            var end = (start + maxChars).coerceAtMost(text.length)
            if (end < text.length) {
                val boundary = text.lastIndexOfAny(charArrayOf('.', '?', '!', '\n'), end)
                if (boundary > start + maxChars / 2) end = boundary + 1
            }
            chunks += text.substring(start, end).trim(); start = end
        }
        return chunks.filter { it.isNotBlank() }
    }
}
