package cl.minutaai.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.Executors

class MeetingDetailActivity : AppCompatActivity() {
    private lateinit var repo: MeetingRepository
    private lateinit var meeting: Meeting
    private lateinit var minutesInput: EditText
    private lateinit var transcriptInput: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var processButton: Button
    private lateinit var engineText: TextView
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_detail); repo = MeetingRepository(this)
        val loaded = intent.getStringExtra("meeting_id")?.let { repo.get(it) }
        if (loaded == null) { Toast.makeText(this, "No encuentro esa reunión.", Toast.LENGTH_LONG).show(); finish(); return }
        meeting = loaded
        findViewById<TextView>(R.id.titleText).text = meeting.title
        findViewById<TextView>(R.id.metaText).text = buildString {
            append(DateFormat.getDateTimeInstance().format(Date(meeting.createdAt))); append(" · ${formatDuration(meeting.durationMs)} · ${meeting.template}")
            if (meeting.participants.isNotBlank()) append("\nParticipantes: ${meeting.participants}")
            if (meeting.transcriptEngine.isNotBlank()) append("\nTranscripción: ${meeting.transcriptEngine}")
        }
        minutesInput = findViewById(R.id.minutesInput); transcriptInput = findViewById(R.id.transcriptInput); progressBar = findViewById(R.id.progressBar); processButton = findViewById(R.id.processButton); engineText = findViewById(R.id.engineText)
        minutesInput.setText(meeting.minutes); transcriptInput.setText(meeting.transcript)
        engineText.text = if (meeting.minuteEngine.isBlank()) "Minuta aún no generada" else "Motor de minuta: ${meeting.minuteEngine}"
        processButton.setOnClickListener { generateMinutes() }
        findViewById<Button>(R.id.saveButton).setOnClickListener { saveEdits(true) }
        findViewById<Button>(R.id.shareButton).setOnClickListener { saveEdits(false); shareMinutes() }
    }
    private fun generateMinutes() {
        saveEdits(false); setProcessing(true)
        executor.execute {
            val result = LocalMinuteEngine(applicationContext).generate(meeting)
            runOnUiThread { meeting.minutes = result.minutes; meeting.minuteEngine = result.engineName; repo.save(meeting); minutesInput.setText(result.minutes); engineText.text = "Motor de minuta: ${result.engineName}"; setProcessing(false); Toast.makeText(this, "Minuta regenerada localmente.", Toast.LENGTH_SHORT).show() }
        }
    }
    private fun setProcessing(value: Boolean) { progressBar.visibility = if (value) View.VISIBLE else View.GONE; processButton.isEnabled = !value; processButton.text = if (value) "Analizando en el teléfono…" else "Regenerar minuta local" }
    private fun saveEdits(showToast: Boolean) { meeting.minutes = minutesInput.text.toString(); meeting.transcript = transcriptInput.text.toString(); repo.save(meeting); if (showToast) Toast.makeText(this, "Cambios guardados.", Toast.LENGTH_SHORT).show() }
    private fun shareMinutes() { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "Minuta - ${meeting.title}"); putExtra(Intent.EXTRA_TEXT, "${meeting.title}\n\n${meeting.minutes}") }, "Compartir minuta")) }
    override fun onDestroy() { executor.shutdownNow(); super.onDestroy() }
    private fun formatDuration(ms: Long): String { val total = ms / 1000; return "%02d:%02d".format(total / 60, total % 60) }
}
